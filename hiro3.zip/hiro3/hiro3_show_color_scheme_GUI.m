function hiro3_show_color_scheme_GUI(varargin)

global hiro3_mem;

onoff = varargin{end};

figure(hiro3_mem.fid_color_scheme_GUI);
clf;
if strcmp(onoff, 'on'),
    set(hiro3_mem.fid_color_scheme_GUI, 'Visible', 'on');
else,
    set(hiro3_mem.fid_color_scheme_GUI, 'Visible', 'off');
end;
set(gcf, 'Name', 'Color schemes');
set(gcf, 'Menubar', 'none');
set(gcf, 'CloseRequestFcn', 'set(gcf, ''Visible'', ''off'');');

nLayers = length(hiro3_mem.layers);
p = get(gcf, 'Position');
p(3) = 400;
p(4) = nLayers * 50;
set(gcf, 'Position', p);

if nLayers < 2,
    text(0.05, 0.5, 'No functional overlay loaded.');
    axis off;
    return;
end;

schemestr = {};
for n = 1:length(hiro3_mem.color_scheme_names),
    schemestr{n} = hiro3_mem.color_scheme_names{n};
end;
transparencystr = {'0', '20', '40', '60', '80', '100'};
for iLayer = 2:nLayers,
    if isempty(hiro3_mem.layers{iLayer}.data),
        continue;
    end;
    d = [];
    for n = 1:length(transparencystr),
        d(n) = abs(str2num(transparencystr{n}) - 100 * hiro3_mem.layers{iLayer}.transparency);
    end;
    [dum, trans_id] = min(d);
    u = uicontrol('style', 'popup', 'String', schemestr);
    set(u, 'Callback', {'hiro3_set_scheme', iLayer, u});
    set(u, 'Value', hiro3_mem.layers{iLayer}.color_id);
    left = 10;
    bottom = (iLayer - 2) * 50;
    width = 150;
    height = 50;
    posrect = [left bottom width height];
    set(u, 'Position', posrect);
    
    u = uicontrol('style', 'popup', 'String', transparencystr);
    set(u, 'Callback', {'hiro3_set_transparency', iLayer, u, transparencystr});
    set(u, 'Value', trans_id);
    left = 170;
    bottom = (iLayer - 2) * 50;
    width = 150;
    height = 50;
    posrect = [left bottom width height];
    set(u, 'Position', posrect);
end;
