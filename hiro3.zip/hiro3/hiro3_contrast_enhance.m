function hiro3_contrast_enhance(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 1,
    return;
end;

if ~isfield(hiro3_mem.layers{1}, 'original_contr'),
    hiro3_mem.layers{1}.original_contr = [];
end;
if isempty(hiro3_mem.layers{1}.original_contr),
    hiro3_mem.layers{1}.original_contr = hiro3_mem.layers{1}.data;
else,
    hiro3_mem.layers{1}.data = hiro3_mem.layers{1}.original_contr;
end;
% Truncate outliers
answer=inputdlg('SDs to truncate','Truncate above x * sd',1,{'3'});
try,
    sdf = str2num(answer{1});
catch,
    return;
end;
if isempty(sdf),
    return;
end;
m = mean(hiro3_mem.layers{1}.data(:));
sd = sqrt(var(hiro3_mem.layers{1}.data(:)));
f = find(hiro3_mem.layers{1}.data > m + sdf * sd);
hiro3_mem.layers{1}.data(f) = m + sdf * sd;
f = find(hiro3_mem.layers{1}.data < m - sdf * sd);
hiro3_mem.layers{1}.data(f) = m - sdf * sd;

hiro3_redraw();
