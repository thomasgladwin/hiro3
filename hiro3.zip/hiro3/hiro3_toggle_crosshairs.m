function hiro3_toggle_crosshairs(varargin)

global hiro3_mem;

hiro3_mem.crosshairs = mod(hiro3_mem.crosshairs + 1, 2);
hiro3_redraw;
