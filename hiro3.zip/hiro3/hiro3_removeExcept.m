function hiro3_removeExcept(varargin)

global hiro3_mem;

response = inputdlg('Enter values to keep', 'Keep', 1);
if ~isempty(response),
    response = str2num(response{1});
    if ~isempty(response),
        iL = hiro3_last_layer;
        tmp = 0 * hiro3_mem.layers{iL}.data;
        for iv = 1:length(response),
            f = find(hiro3_mem.layers{iL}.data == response(iv));
            tmp(f) = hiro3_mem.layers{iL}.data(f);
        end;
        hiro3_mem.layers{iL}.data = tmp;
        hiro3_redraw;
    end;
end;

hiro3_redraw;
