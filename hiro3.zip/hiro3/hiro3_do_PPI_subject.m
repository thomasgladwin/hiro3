function PPI_X = hiro3_do_PPI_subject(savename, onsetsmat, TR, funcscans, mask0, movementRegr, contrCoeff)

% function PPI_X = do_PPI_subject(savename, onsetsmat, TR, funcscans, mask0, movementRegr, contrCoeff)
%
% Thomas E. Gladwin, 2016
%
% Method based on O'Reilly JX et al. (2012), SCAN.
%
% Example code for input:
% x = dir('swra*.nii'); funcscans = {}; for n = 1:length(x), funcscans{n} = ['Z:\DataLieke\PPIScriptData\xm13101101_3_1\' x(n).name]; end;
% onsetsmat = 'Z:\DataLieke\PPIScriptData\onsets_011.mat';
% mask0 = 'Z:\DataLieke\PPIScriptData\rAmygdala_L.nii';
% movementRegr = 'Z:\DataLieke\PPIScriptData\rp_xm13101101_3_1-0001.txt';
% contrCoeff = [0 -1 1 0]';

nScans = length(funcscans);
load(onsetsmat); % Gives names and durations
X = generate_design(onsets, durations, TR, nScans);
if ~isempty(movementRegr),
    MR = dlmread(movementRegr);
    X = [X MR];
end;
timecourse = get_timecourse(funcscans, mask0);
contrVec = X(:, 1:length(contrCoeff)) * contrCoeff(:);
ppi_regr = timecourse .* contrVec;
PPI_X = [ppi_regr timecourse X];
calculate_beta_maps(PPI_X, funcscans, savename);

function X = generate_design(onsets, durations, TR, nScans)
% function X = generate_design(onsets, durations, TR, nScans)
timeTotal = nScans * TR;
sampleInt = 0.1;
nSamples = timeTotal / sampleInt;
[hrf, p] = spm_hrf(sampleInt);
X = [];
for iPred = 1:length(onsets),
    vec = zeros(nSamples, 1);
    iSamples = max(1, ceil(onsets{iPred} / sampleInt));
    if durations{iPred}(1) == 0,
        vec(iSamples) = 1;
    else,
        durSa = ceil(durations{iPred} / sampleInt);
        for iiSample = 1:length(iSamples),
            if length(durSa) == 1,
                w = durSa(1);
            else,
                w = durSa(iiSample);
            end;
            for sa = 0:w,
                a = iSamples(iiSample) + sa;
                vec(a) = 1 ./ w;
            end;
        end;
    end;
    vec = conv(vec, hrf);
    vec = vec(1:nSamples);
    vec = zscore(vec);
    X = [X vec];
end;
indices = floor(linspace(1, nSamples, nScans));
X = X(indices, :);
% Extra predictors
% Intercept
X = [X ones(size(X, 1), 1)];
% High-pass
T0 = timeTotal * 2;
f0 = 1 / T0;
while f0 < (1 / 128),
    t = ((1:size(X, 1)) - 1) * TR;
    t = t(:);
    cos0 = cos(2 * pi * f0 * t);
    X = [X cos0];
    f0 = f0 * 2;
end;

function timecourse = get_timecourse(funcscans, mask0)
H = spm_vol(mask0);
Mask = spm_read_vols(H);
fMask = find(Mask == 1);
A = [];
for iScan = 1:length(funcscans),
    H = spm_vol(funcscans{iScan});
    D = spm_read_vols(H);
    regionValues = D(fMask);
    A = [A; regionValues(:)'];
end;
m = mean(A, 2);
m = m - mean(m);
A = A - (ones(size(A, 1), 1) * mean(A));
[O2L, Lambda] = eig(cov(A));
F = A * O2L;
l = F(:, end);
timecourse = l;

function calculate_beta_maps(PPI_X, funcscans, savename)
H = spm_vol(funcscans{1});
betaMap = spm_read_vols(H);
betaMap(:) = 0;
D = {};
Y = zeros(length(betaMap(:)), length(funcscans));
for iScan = 1:length(funcscans),
    H = spm_vol(funcscans{iScan});
    thisD = spm_read_vols(H);
    D{iScan} = thisD;
    Y(:, iScan) = thisD(:);
end;
B = inv(PPI_X' * PPI_X) * PPI_X' * (Y');
betaMap(:) = B(1, :);
H.fname = savename;
H.dt = [16 0];
spm_write_vol(H, betaMap);

