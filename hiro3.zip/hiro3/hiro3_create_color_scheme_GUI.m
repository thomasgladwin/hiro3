function hiro3_create_color_scheme_GUI

% Create color scheme GUI

global hiro3_mem;

hiro3_mem.fid_color_scheme_GUI = figure;
set(hiro3_mem.fid_color_scheme_GUI, 'Visible', 'off');
