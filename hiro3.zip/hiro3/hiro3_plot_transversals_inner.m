function hiro_plot_transversals_inner(slice_select, iView)

global hiro3_mem;

for iLayer = 2:length(hiro3_mem.layers),
    inner_inner(slice_select, iLayer, iView);
end;

function inner_inner(slice_select, layer_select, iView)

global hiro3_mem;

hiro3_temp.ax0 = [];

iViewDim1 = iView + 1; if iViewDim1 > 3, iViewDim1 = iViewDim1 - 3; end;
iViewDim2 = iView + 2; if iViewDim2 > 3, iViewDim2 = iViewDim2 - 3; end;

%figure(hiro3_mem.fid);
figure; clf; hiro3_add_print_menu;
set(gcf, 'Color', 'none');
colormap(hiro3_mem.colormap);
set(gcf, 'Name', 'Hiro3_Transversal_Slices');
set(gcf, 'PaperPositionMode', 'auto');
set(gcf, 'Position', [548 198 285 * 1.3 400 * 1.3]);
% Background
set(gcf, 'Color', [0 0 0] + 0.01);
axes('Position', [0 0 1 1]); 
im0 = image([0 1], [0 1], [1 1; 1 1], 'CDataMapping', 'direct');
set(gca, 'XTick', []); set(gca, 'YTick', []);

% Remove intro pic axes if onscreen.
if hiro3_mem.intro_axes ~= 0,
    delete(hiro3_mem.intro_axes);
    hiro3_mem.intro_axes = 0;
end;

% Remove previous plot axes.
for n = 1:length(hiro3_temp.ax0),
    try,
        if hiro3_temp.ax0(n) > 0,
            delete(hiro3_temp.ax0(n));
            hiro3_temp.ax0(n) = 0;
        end;
    catch,
        fprintf('Could not delete axes.\n');
        fprintf(lasterr);
    end;
end;

% check if anything is loaded
x = 0;
first = 0;
for iLayer = 1:length(hiro3_mem.layers),
    if ~isfield(hiro3_mem.layers{iLayer}, 'data'),
        continue;
    end;
    if prod(size(hiro3_mem.layers{iLayer}.data)) > 0,
        x = 1;
        first = iLayer;
        break
    end;
end;
if x == 0,
    hiro3_temp.ax0(1) = axes('position', [0 0 1 1]);
    set(gca, 'Color', [0.2 0.2 0.2]);
    axis off;
    return;
end;

% Params
margin = 0.01 * 1;
text_area = 0.1;
lastLayer = hiro3_last_layer;
% Plot views of layers
% Anatomy and functional values wil be scaled to fit into
% correct segments of a static colormap.
%
% Scale axes:
%   Horizontal: l2 : l1 : l1
%   Vertical: l3 : l3 : l2

H_scale = [1 1 1];
V_scale = [1 1 1];
%common_lim = [min(hiro3_mem.min_BB) max(hiro3_mem.max_BB)];
%common_lim_hor = [hiro3_mem.min_BB(1) hiro3_mem.max_BB(1)];
%common_lim_ver = [hiro3_mem.min_BB(2) hiro3_mem.max_BB(2)];

f = find(hiro3_mem.layers{1}.data ~= 0);
common_lim_hor(1) = min(hiro3_mem.layers{1}.xyz(iViewDim2, f));
common_lim_hor(2) = max(hiro3_mem.layers{1}.xyz(iViewDim2, f));
common_lim_ver(1) = min(hiro3_mem.layers{1}.xyz(iViewDim1, f));
common_lim_ver(2) = max(hiro3_mem.layers{1}.xyz(iViewDim1, f));

left = margin;
perPlot = (1 - 0 * margin) / size(hiro3_mem.layers{1}.data, 3);
clim0 = [1 size(hiro3_mem.colormap, 1)];
maxabs = [];

for iLayer = 1:length(hiro3_mem.layers),
    allmin{iLayer} = min(hiro3_mem.layers{iLayer}.data(:));
    allmax{iLayer} = max(hiro3_mem.layers{iLayer}.data(:));
    allmax{iLayer} = max(abs(hiro3_mem.layers{iLayer}.data(:)));
end;
% Find anatomy associated with activation slices
slice_vec = {};
func_slices_to_plot = [];
if length(hiro3_mem.layers) > 1,
    iiSlice = 0;
    for iSlice = 1:size(hiro3_mem.layers{layer_select}.data, iView),
        iLayer = layer_select;
        for n = 1:3,
            dimsel{n} = 1:size(hiro3_mem.layers{iLayer}.data, n);
        end;
        dimsel{iView} = iSlice;
        toplot = hiro3_mem.layers{iLayer}.data(dimsel{1}, dimsel{2}, dimsel{3});
        toplot = squeeze(toplot);
        if iLayer > 1,
            toplot(find(abs(toplot) < hiro3_mem.layers{iLayer}.cutoff)) = 0;
        end;
        toplot = toplot'; % higher dimension is rows
        if max(toplot(:)) == min(toplot(:)),
            %continue;
        end;
%         if isempty(find(iSlice == slice_choices)),
%             continue;
%         end;
        if iView == 3,
            ind0 = sub2ind(size(hiro3_mem.layers{layer_select}.data), 1, 1, iSlice);
        elseif iView == 1,
            ind0 = sub2ind(size(hiro3_mem.layers{layer_select}.data), iSlice, 1, 1);
        else,
            ind0 = sub2ind(size(hiro3_mem.layers{layer_select}.data), 1, iSlice, 1);
        end;
        z = hiro3_mem.layers{iLayer}.xyz(iView, ind0);
        if min(abs(z - slice_select)) >= hiro3_mem.layers{layer_select}.headerinfo.mat(iView, iView),
            continue;
        end;
        func_slices_to_plot = [func_slices_to_plot iSlice];
        iiSlice = iiSlice + 1;
        for iLayer = 1:length(hiro3_mem.layers),
            d0 = abs(hiro3_mem.layers{iLayer}.xyz(iView, :) - z);
            [dum, f] = min(d0); 
            f = f(1);
            [dim00(1), dim00(2), dim00(3)] = ind2sub(size(hiro3_mem.layers{iLayer}.data), f);
            slice_vec{iLayer}(iiSlice) = dim00(iView);
            z00(iiSlice) = z;
        end
    end;
else,
    slice_vec{1} = slice_choices;
end;

%  Plot slices
axes_created = 0;
N = length(slice_vec{iLayer});
if N < 4,
    nR = 1; nC = N;
elseif N == 4,
    nR = 2; nC = 2;
elseif N < 7,
    nR = 2; nC = 3;
elseif N == 8,
    nR = 2; nC = 4;
elseif N == 9,
    nR = 3; nC = 3;
elseif N < 13,
    nC = 4; nR = ceil(N / nC);
else,
    nR = ceil(sqrt(length(slice_vec{iLayer})));
    nC = ceil(length(slice_vec{iLayer}) / nR);
end;
p0 = get(gcf, 'Position');
rel = common_lim_hor / common_lim_ver;
rel = rel * (1 - text_area);
p0(3:4) = [nC * 200 * rel, nR * 200];
set(gcf, 'Position', p0);
% width = (1 - 2 * margin) / (nC);
% height = (1 - text_area - margin) / (nR);
% width = (1 - 2 * margin) * max(1, mod(2 - 1, nC)) / (nC);
% height = (floor((nC) / nC) / (nR)) * (1 - text_area - margin);
width = (1 - 2 * nC * margin) / (nC);
height = (1 - 2 * nR * margin - text_area) / (nR);
for iiLayer = 1:2,
    if iiLayer == 1,
        iLayer = 1;
    else,
        iLayer = layer_select;
    end;
    if prod(size(hiro3_mem.layers{iLayer}.data)) == 0,
        continue;
    end;
    for iiSlice = 1:length(slice_vec{iLayer}),
        iSlice = slice_vec{iLayer}(iiSlice);
        % set up axes
        left = mod(iiSlice - 1, nC) * width;
        bottom = text_area + floor((iiSlice - 1) / nC) * height;
        posrect = [left bottom width height];
        %posrect = [left bottom min(width, height) min(width, height)];
        if axes_created == 0,
            hiro3_temp.ax0(iiSlice) = axes('position', posrect);
        else
            axes(hiro3_temp.ax0(iiSlice));
        end;
        axis off;
        hold on;
        maxabs(iLayer) = max(abs(hiro3_mem.layers{iLayer}.data(:)));
        %        try,
        % get plane
        for n = 1:3,
            dimsel{n} = 1:size(hiro3_mem.layers{iLayer}.data, n);
        end;
        dimsel{iView} = iSlice;
        if dimsel{iView} == 0 || dimsel{iView} > size(hiro3_mem.layers{iLayer}.data, iView),
            dimsel{iView} = ceil(size(hiro3_mem.layers{iLayer}.data, iView) / 2);
        end;
        toplot = hiro3_mem.layers{iLayer}.data(dimsel{1}, dimsel{2}, dimsel{3});
        toplot = squeeze(toplot);
        if iLayer > 1,
            toplot(find(abs(toplot) < hiro3_mem.layers{iLayer}.cutoff)) = 0;
        end;
        toplot = toplot'; % higher dimension is rows
        if max(toplot(:)) == min(toplot(:)),
            continue;
        end;
        % Get x, y scales for current layer
        BB_max0 = hiro3_mem.layers{iLayer}.max_BB;
        BB_min0 = hiro3_mem.layers{iLayer}.min_BB;
        BB_max0(iView) = [];
        BB_min0(iView) = [];
        X = linspace(BB_min0(1), BB_max0(1), size(toplot, 2)); % horizontal axis: columns
        Y = linspace(BB_min0(2), BB_max0(2), size(toplot, 1));
        % plot plane
        if iLayer == 1,
            % Grayscale anatomy
            if max(toplot(:)) > min(toplot(:)),
                toplot = hiro3_mem.colors.starts(1) + floor((hiro3_mem.colors.ends(1) - hiro3_mem.colors.starts(1)) * (toplot - allmin{iLayer}) / (allmax{iLayer} - allmin{iLayer}));
                im0 = image(X, Y, toplot, 'CDataMapping', 'direct');
            else,
                continue;
            end;
        else,
            if max(toplot(:)) > min(toplot(:)),
                % plot equal ranges around 0
                cid = hiro3_mem.layers{iLayer}.color_id;
                if cid >= 2 && cid <= 5,
                    % flat color
                    toplot_temp = zeros(size(toplot));
                    f = find(toplot > 0);
                    toplot_temp(f) = hiro3_mem.colors.ends(cid);
                    f = find(toplot < 0);
                    toplot_temp(f) = hiro3_mem.colors.starts(cid);
                elseif cid == 8,
                    toplot_temp = hiro3_mem.colors.starts(cid) + (hiro3_mem.colors.ends(cid) - hiro3_mem.colors.starts(cid)) * (toplot - 1) / allmax{iLayer};
                else,
                    % scales
                    half = floor((hiro3_mem.colors.ends(cid) - hiro3_mem.colors.starts(cid)) / 2);
                    zero = hiro3_mem.colors.starts(cid) + half;
                    %toplot_temp = zero + floor(half * toplot / max(abs(toplot(:))));
                    %toplot_temp = zero + floor(half * toplot / allmax{iLayer});
                    toplot_temp = zeros(size(toplot));
                    f = find(toplot > 0);
                    toplot_temp(f) = zero + ceil(half * (toplot(f) - hiro3_mem.layers{iLayer}.cutoff) / (allmax{iLayer} - hiro3_mem.layers{iLayer}.cutoff));
                    f = find(toplot < 0);
                    toplot_temp(f) = zero + floor(half * (toplot(f) + hiro3_mem.layers{iLayer}.cutoff) / (allmax{iLayer} + hiro3_mem.layers{iLayer}.cutoff));
                end;
                im0 = image(X, Y, toplot_temp, 'CDataMapping', 'direct');
            else,
                continue;
            end;
        end;
        set(gca, 'YDir', 'normal');
        axis off;
        buf = diff(common_lim_ver(:)) / 50;
        common_lim_ver = common_lim_ver(:) + [-buf; buf];
        buf = diff(common_lim_hor(:)) / 50;
        common_lim_hor = common_lim_hor(:) + [-buf; buf];
        xlim(common_lim_hor);
        ylim(common_lim_ver);
%        axis equal;
        if axes_created == 0,
            %t0 = text(1 * common_lim(2), common_lim(1) + 0.2 * diff(common_lim), num2str(z00(iiSlice)));
            %set(t0, 'Color', [1 1 1]);
        end;
        % Colouring etc options
        if iLayer > 1,
            alphadata = zeros(size(toplot));
            f = find(abs(toplot) > 0);
            alphadata(f) = 1 - hiro3_mem.layers{iLayer}.transparency;
            set(im0, 'AlphaData', alphadata);
        end;
        % Transparency
        set(hiro3_temp.ax0(iiSlice), 'Color', 'none');
    end;
    axes_created = 1;
end;
% Re-do text
axes('Position', [0 0 1 1]);
set(gca, 'Color', 'none');
axis off;
for iiSlice = 1:length(slice_vec{iLayer}),
    left = (1 - 2 * margin) * mod(iiSlice - 1, nC) / (nC);
    bottom = text_area + (floor((iiSlice - 1) / nC) / (nR)) * (1 - text_area - margin);
    %t0 = text(1 * common_lim(2), common_lim(1) + 0.2 * diff(common_lim), num2str(z00(iiSlice)));
    t0 = text(left, bottom + 0*height / 2, num2str(z00(iiSlice)));
    set(t0, 'Color', [1 1 1] * 0.9);
end;
% Info region
% Colorbars for activation layers
for iLayer = layer_select,
    if isempty(hiro3_mem.layers{iLayer}.data),
        continue;
    end;
    if maxabs(iLayer) == 0,
        continue;
    end;
    left = margin;
    width = 1 - 8 * margin;
    height = text_area;
    bottom = 0*text_area + (iLayer - 1) * 1.25 * height;
    posrect = [left bottom width height];
    posrect = [0 0 1 height];
    hiro3_temp.ax0(length(hiro3_temp.ax0) + 1) = axes('position', posrect);
    axis off;
    set(gca, 'Color', 'none');
   
    scale = linspace(-maxabs(iLayer), maxabs(iLayer), 64);
    %scale = [zeros(1, 5) scale zeros(1, 5)];
    scale = [1; 1] * scale;
    % plot equal ranges around 0
    cid = hiro3_mem.layers{iLayer}.color_id;
    if cid >= 2 && cid <= 5,
        % flat color
        toplot_temp = zeros(size(scale));
        f = find(scale > 0);
        toplot_temp(f) = hiro3_mem.colors.ends(cid);
        f = find(scale < 0);
        toplot_temp(f) = hiro3_mem.colors.starts(cid);
    elseif cid == 8, % discrete
        toplot_temp = hiro3_mem.colors.starts(cid):hiro3_mem.colors.ends(cid);
        scale = 1:length(toplot_temp);
    else,
        % scales
        half = floor((hiro3_mem.colors.ends(cid) - hiro3_mem.colors.starts(cid)) / 2);
        zero = hiro3_mem.colors.starts(cid) + half;
        toplot_temp = zero + floor(half * scale / max(abs(scale(:))));
    end;
    im0 = image(1:length(scale), [0.1; 0.3], toplot_temp, 'CDataMapping', 'direct');
    set(gca, 'YDir', 'normal');
    axis off;
    set(gca, 'YTick', []);
    set(gca, 'XTick', []);
    xl = [1 length(scale(1, :))];
    d0 = length(scale(1, :)); m0 = d0 / 5; 
    xlim(xl + [-m0 m0]);
    xl = xlim;
    ylim([0 1])
    if cid ~= 8,
        t = text(xl(1) + m0 / 2, 0.1, num2str(-maxabs(iLayer), 2));
        set(t, 'Color', [1 1 1] * 0.9);
        set(t, 'HorizontalAlignment', 'Center');
        set(t, 'VerticalAlignment', 'Bottom');
        t = text(xl(2) - m0 / 2, 0.1, num2str(maxabs(iLayer), 2));
        set(t, 'Color', [1 1 1] * 0.9);
        set(t, 'HorizontalAlignment', 'Center');
        set(t, 'VerticalAlignment', 'Bottom');
    end;
    t = text(mean(xl), 0.7, ['threshold = ' num2str(hiro3_mem.layers{iLayer}.cutoff)]);
    set(t, 'Color', [1 1 1] * 0.9);
    set(t, 'HorizontalAlignment', 'Center');
    set(t, 'VerticalAlignment', 'Top');
    set(gca, 'Clipping', 'off');
end;
