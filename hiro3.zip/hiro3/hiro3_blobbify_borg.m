function hiro3_blobbify_borg(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 2,
    fprintf('Please load an activation map.\n');
    return;
elseif isempty(hiro3_mem.layers{2}.data),
    fprintf('Please load an activation map.\n');
    return;
end;

fn = hiro3_mem.layers{2}.filename;
fn = fn(1:(end - 2));
[savename, pathname] = uiputfile( ...
    {'*.nii'}, ...
    'Save label map as...', fn);
if savename == 0,
    return;
end;

response = inputdlg('Combine clusters with <param = 0 to 1> shared edge-voxels? Zero = always, to 1 = Never', 'Parameter', 1, {'1'});
if isempty(response),
    return;
end;
comm0 = ['param0 = ' response{1} ';'];
try,
    eval(comm0);
catch,
    fprintf(['Cannot eval ' comm0 '\n']);
    return;
end;

response = inputdlg('Enter minimum number of voxels per blob', 'Parameter', 1, {'3'});
if isempty(response),
    return;
end;
comm0 = ['minnum0 = ' response{1} ';'];
try,
    eval(comm0);
catch,
    fprintf(['Cannot eval ' comm0 '\n']);
    return;
end;

axid = hiro3_popup_message_on('Running blobbify...');

[dum, base0, ext] = fileparts(savename);
[L, info] = hiro3_islander_iterative_borg(hiro3_mem.layers{2}.data, hiro3_mem.layers{2}.cutoff, param0, minnum0);
info = hiro3_saveIslInfo([pathname '/' base0 '.txt'], info);
LH = hiro3_mem.layers{2}.headerinfo;
LH.fname = [pathname savename];
if isempty(ext),
    LH.fname = [LH.fname '.nii'];
end;
spm_write_vol(LH, L);

hiro3_popup_message_off(axid);

hiro3_redraw;
