function hiro3_load_file_inner(filename, iLayer, fileTypeStr, reslice)

global hiro3_mem;

% Load data and set up layer information.
hiro3_mem.lastfilename = filename;
hiro3_init_layer(iLayer, fileTypeStr);
hiro3_mem.layers{iLayer}.filename = filename;
hiro3_mem.layers{iLayer}.headerinfo = spm_vol(filename);
[hiro3_mem.layers{iLayer}.data, hiro3_mem.layers{iLayer}.xyz] = spm_read_vols(hiro3_mem.layers{iLayer}.headerinfo);
hiro3_mem.layers{iLayer}.coords = ceil(size(hiro3_mem.layers{iLayer}.data) ./ 2);
hiro3_mem.layers{iLayer}.cutoff = hiro3_mem.cutoff;

if iLayer == 1,
    min0 = min(hiro3_mem.layers{iLayer}.data(:));
    max0 = max(hiro3_mem.layers{iLayer}.data(:));
    hiro3_mem.layers{iLayer}.data = (hiro3_mem.layers{iLayer}.data - min0) / max0;
end;

% reslice if specified
if reslice == 1 || 1 == 1,
    hiro3_reorient(iLayer);
    % hiro3_spm_reslice(iLayer); % reslices...?
end;

% Determine new maximum bounding box
hiro3_mem.max_BB = [];
hiro3_mem.min_BB = [];
for iiLayer = 1:length(hiro3_mem.layers),
    if size(hiro3_mem.layers{iiLayer}.xyz, 2) > 1,
        max0 = max(hiro3_mem.layers{iiLayer}.xyz');
        min0 = min(hiro3_mem.layers{iiLayer}.xyz');
    else,
        continue;
    end;
    hiro3_mem.layers{iiLayer}.max_BB = max0;
    hiro3_mem.layers{iiLayer}.min_BB = min0;
    if isempty(hiro3_mem.max_BB),
        hiro3_mem.max_BB = hiro3_mem.layers{iiLayer}.max_BB;
        hiro3_mem.min_BB = hiro3_mem.layers{iiLayer}.min_BB;
    else,
        for n = 1:3,
            hiro3_mem.max_BB(n) = max(hiro3_mem.max_BB(n), hiro3_mem.layers{iiLayer}.max_BB(n));
            hiro3_mem.min_BB(n) = min(hiro3_mem.min_BB(n), hiro3_mem.layers{iiLayer}.min_BB(n));
        end;
    end;
end;

% Set starting coords to preexisting data set
xyz = [];
for iiLayer = 1:length(hiro3_mem.layers),
    if iiLayer == iLayer,
        continue;
    end;
    if length(hiro3_mem.layers{iiLayer}.coords) > 1,
        xyz_index = sub2ind(size(hiro3_mem.layers{iiLayer}.data), hiro3_mem.layers{iiLayer}.coords(1), hiro3_mem.layers{iiLayer}.coords(2), hiro3_mem.layers{iiLayer}.coords(3));
        xyz = hiro3_mem.layers{iiLayer}.xyz(:, xyz_index);
        break;
    end;
end;
if ~isempty(xyz),
    d = hiro3_mem.layers{iLayer}.xyz - xyz * ones(1, size(hiro3_mem.layers{iLayer}.xyz, 2));
    [dum0, ind0] = min(sum(abs(d)));
    ind0 = ind0(1);
    [cx, cy, cz] = ind2sub(size(hiro3_mem.layers{iLayer}.data), ind0);
    hiro3_mem.layers{iLayer}.coords = [cx cy cz];
%     for n = 1:3,
%         tmp = xyz(n) - hiro3_mem.layers{iLayer}.min_BB(n);
%         tmp = tmp / (hiro3_mem.layers{iLayer}.max_BB(n) - hiro3_mem.layers{iLayer}.min_BB(n));
%         tmp = ceil(tmp * size(hiro3_mem.layers{iLayer}.data, n));
%         hiro3_mem.layers{iLayer}.coords(n) = tmp;
%     end;
end;

% Set color_id (anatomy grayscale is default)
% 1. Grayscale
% 2. BW
% 3. Red
% 4. Green
% 5. Blue
% 6. Winter - Hot
% 7. Cool - Summer
% 8. Discrete
u = unique(hiro3_mem.layers{iLayer}.data);
if length(u) == 2,
    hiro3_mem.layers{iLayer}.color_id = 1;
else,
    if iLayer == 2,
        hiro3_mem.layers{iLayer}.color_id = 6;
    else,
        hiro3_mem.layers{iLayer}.color_id = 7;
    end;
end;
% Reorganize windows if open
fid = gcf;
visible = get(hiro3_mem.fid_color_scheme_GUI, 'Visible');
hiro3_show_color_scheme_GUI(visible);
figure(fid);
% Forget changes
hiro3_mem.changes = {};

hiro3_redraw;

f = find(~isnan(hiro3_mem.layers{iLayer}.data) & hiro3_mem.layers{iLayer}.data > 0);
% fprintf([num2str(length(f)) ' voxels in dataset. FWE p = ' num2str(0.05 / length(f)) '\n']);
