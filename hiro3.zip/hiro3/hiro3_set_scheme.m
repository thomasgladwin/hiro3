function hiro3_set_scheme(dum1, dum2, iLayer, u);

global hiro3_mem;

value = get(u, 'Value');
hiro3_mem.layers{iLayer}.color_id = value;
hiro3_redraw;
