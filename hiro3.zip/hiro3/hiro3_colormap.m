function RGB_Total = hiro3_colormap

global hiro3_mem;

RGB_Total = [];
counter = 1;
n = 1;

nCol = 128;

% 1. Grayscale
hiro3_mem.color_scheme_names{n} = 'Grayscale';
basis = (1:(nCol + 1))';
basis = (basis - 1) ./ nCol;
c = mean(basis);
% c = c - sqrt(var(basis));
basis = 1 ./ (1 + exp(-3 * (basis - c)));
basis = basis - min(basis);
basis = basis ./ max(basis);
RGB = basis * ones(1, 3);
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

% 2. Black / white
hiro3_mem.color_scheme_names{n} = 'Black and white';
RGB = [0.5 0.5 0.5; 0 0 0; 1 1 1];
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = hiro3_mem.colors.ends(n - 1) + 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

% 3. Red
hiro3_mem.color_scheme_names{n} = 'Red';
RGB = [0.5 0 0; 0 0 0; 1 0 0];
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = hiro3_mem.colors.ends(n - 1) + 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

% 4. Yellow
hiro3_mem.color_scheme_names{n} = 'Yellow';
RGB = [0.5 0.5 0; 0 0 0; 1 1 0];
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = hiro3_mem.colors.ends(n - 1) + 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

% 5. Blue
hiro3_mem.color_scheme_names{n} = 'Blue';
RGB = [0 0 0.5; 0 0 0; 0 0 1];
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = hiro3_mem.colors.ends(n - 1) + 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

% 6. Functional 1
hiro3_mem.color_scheme_names{n} = 'Winter - Hot';
w = colormap('winter');
w = w .* ((size(w, 1):(-1):1)' * [1 1 1]);
w = w ./ max(w(:));
RGB = [w; [0 0 0]; colormap('hot')];
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = hiro3_mem.colors.ends(n - 1) + 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

% 7. Functional 2
hiro3_mem.color_scheme_names{n} = 'Cool - Summer';
w = colormap('cool');
w = w .* ((size(w, 1):(-1):1)' * [1 1 1]);
w = w ./ max(w(:));
RGB = [w; [0 0 0]; colormap('summer')];
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = hiro3_mem.colors.ends(n - 1) + 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

% 8. Discrete
hiro3_mem.color_scheme_names{n} = 'Discrete colors';
RGB = [1 0 0; 0 1 0; 0 0 1; 1 1 0; 1 0 1; 0 1 1; 1 0.5 0.5; 0.5 1 0.5; 0.5 0.5 1; 0.75 0.5 0.75; 0.5 0.75 0.25; 0.75 0.25 0.5];
RGB_Total = [RGB_Total; RGB];
hiro3_mem.colors.starts(n) = hiro3_mem.colors.ends(n - 1) + 1;
hiro3_mem.colors.ends(n) = hiro3_mem.colors.starts(n) + size(RGB, 1) - 1;
n = n + 1;

hiro3_mem.colormap = RGB_Total;
