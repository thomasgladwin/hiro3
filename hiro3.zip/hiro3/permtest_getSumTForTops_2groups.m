function R = permtest_getSumTForTops_2groups(filenames, nIts, sizeOrT, bn_save, LandC, threshold0)

% sizeOrT:
%   0 = size
%   1 = sum-t
%   2 = median t
%   3 = min t

R.nIts = nIts;
R.filenames = filenames;
R.sizeOrT = sizeOrT;
R.LandC = LandC;
R.threshold0 = threshold0;

R.D = {};
for iGr = 1:2,
    for ix = 1:length(R.filenames{iGr}),
        fn = [R.filenames{iGr}{ix}];
        H = spm_vol(fn);
        [R.D{iGr}{ix}, R.XYZ] = spm_read_vols(H);
    end;
end;

[R.nBlobsReal, R.maxBlobPowerReal, R.tcrit, R.info, R.sumTReal, R.L, R.H, R.sumT, R.Torig, R.N] = inner_perm(R, 0);
fprintf(['\tReal data: nBlobs = ' num2str(R.nBlobsReal) ', max score = ' num2str(max(R.maxBlobPowerReal)) '.\n']);

if R.LandC == 0,
    [R.nBlobs, R.maxBlobPowers, R.maxBlobPower95] = inner(R);
    R.f_sig_blobs = find(R.sumTReal > R.maxBlobPower95);
    fprintf(['\tMax T sum 95 = ' num2str(R.maxBlobPower95) '\n\nnr val N x y z p\n']);
    x = R.sumTReal;
    R.p_per_blob = [];
    for ix = 1:length(x), 
        x0 = x(ix);
        f = find(R.maxBlobPowers >= x0); 
        p = length(f) / length(R.maxBlobPowers);
        N = R.N(ix);
        R.p_per_blob(ix) = p;
        xi = ceil(R.info.mean_ind(ix, 1));
        yi = ceil(R.info.mean_ind(ix, 2));
        zi = ceil(R.info.mean_ind(ix, 3));
        fi = sub2ind(size(R.L), xi, yi, zi);
        x2 = R.XYZ(1, fi, 1);
        y2 = R.XYZ(2, fi, 1);
        z2 = R.XYZ(3, fi, 1);
        disp([ix x0 N x2 y2 z2 p]);
    end;
else,
    R.f_sig_blobs = 1:length(R.sumTReal);
end;

R.nBlobsSig = length(R.f_sig_blobs);
fprintf(['\n\tReal data: nBlobs = ' num2str(R.nBlobsReal) ', max score = ' num2str(max(R.maxBlobPowerReal)) ', nBlobs sig = ' num2str(R.nBlobsSig) '.\n']);

% Save label map / mask and T
savelab = {'Lsig_', 'T_', 'L_'};
for iDataToSave = 1:3,
    fn = R.filenames{1}{1};
    H = spm_vol(fn);
    H.fname = [savelab{iDataToSave} bn_save '.nii'];
    if iDataToSave == 1,
        keeplabels = R.info.label(R.f_sig_blobs);
        tmp = 0 * R.L;
        for il = 1:length(keeplabels),
            f = find(R.L == keeplabels(il));
            tmp(f) = keeplabels(il);
        end;
        R.Lsig = tmp;
        clear tmp;
        H.dt = [16 0]; % [4 0]
        D = R.Lsig;
    elseif iDataToSave == 2,
        H.dt = [16 0];
        D = R.Torig;
    elseif iDataToSave == 3,
        H.dt = [16 0]; %[4 0]
        D = R.L;
    end;
    spm_write_vol(H, D);
end;

function [nBlobs, maxBlobPowers, maxBlobPower95] = inner(R)
nBlobs = [];
maxBlobPowers = [];
dispstr = '';
for iIt = 1:R.nIts,
    [nBlobs0, maxBlobPower0, R.tcrit, info, sumtv, L, H, sumT] = inner_perm(R, 1);
    nBlobs = [nBlobs; nBlobs0];
    maxBlobPowers = [maxBlobPowers; maxBlobPower0];
    dispstr = ['Iteration ' num2str(iIt) ': nBlobs = ' num2str(nBlobs0) ', max T sum = ' num2str(mean(maxBlobPower0)) '\n'];
    fprintf(dispstr);
end;
sorted = sort(maxBlobPowers, 'ascend');
a = ceil(0.95 * length(sorted));
maxBlobPower95 = sorted(a);

function [nBlobs, maxBlobPower0, tcrit, info, sumtv, L, H, sumT, T, Nvec] = inner_perm(R, permit0)
fn = [R.filenames{1}{1}];
H = spm_vol(fn);
[D] = spm_read_vols(H);

S2{1} = zeros(size(D));
S{1} = zeros(size(D));
S2{2} = zeros(size(D));
S{2} = zeros(size(D));

for iGr = 1:2,
    for ix = 1:length(R.filenames{iGr}),
        D = R.D{iGr}{ix};
        iGr0 = iGr;
        if permit0 == 1,
            iGr0 = floor(2 * rand) + 1;
        end;
        S{iGr0} = S{iGr0} + D;
        S2{iGr0} = S2{iGr0} + D .^ 2;
    end;
end;

for iGr = 1:2,
    N{iGr} = length(R.filenames{iGr});
    M{iGr} = S{iGr} ./ N{iGr};
    V{iGr} = (S2{iGr} - (S{iGr} .^ 2) / N{iGr}) / (N{iGr} - 1);
end;

clear S
clear S2

SE = sqrt(V{1} / N{1} + V{2} / N{2});
T = (M{1} - M{2}) ./ SE;
df = (V{1} ./ N{1} + V{2} ./ N{2}) .^ 2 ./ ...
    ((V{1}./N{1}) .^ 2 ./ (N{1} - 1) + (V{2}./N{2}) .^ 2 ./ (N{2} - 1));

clear M
clear V
clear SE

T(T == 0) = NaN;
T(isinf(T)) = NaN;
T = abs(T);
try,
    T = 1 - tcdf(T, df); % Replace T by p-based values
catch,
    dfdf=0;
end;

fOverPCrit = find(T > R.threshold0);
T(fOverPCrit) = NaN;

% T(T == 0) = eps;
% T(T > 0.05) = NaN;
fnz = find(T > 0);
T(fnz) = log(T(fnz))/log(0.05);
% T(isnan(T)) = 0;
tcrit = 0;

if R.LandC == 0,
    if R.sizeOrT == 0,
        [L, info] = islander_recursive2016(T, 1);
    else,
        [L, info] = islander_recursive2016(T);
    end;
else
    [L, info] = islander_recursive2016(T, 1);
    u = unique(L);
    u(u == 0) = [];
    info.label = [];
    for iu = 1:length(u),
        f = find(L == u(iu));
        if length(f) < 20,
            L(f) = NaN;
        else,
            info.label = [info.label; u(iu)];
        end;
    end;
end;

nBlobs = info.N;

u = info.label;
sumtv = [];
sumT = zeros(size(T));
Nvec = [];
if length(u) > 0,
    for iu = 1:length(u),
        f = find(L == u(iu));
        Nvec = [Nvec; length(f)];
        if R.sizeOrT == 0,
            sumt0 = length(f);
            sumtv = [sumtv; sumt0];
        elseif R.sizeOrT == 1,
            sumt0 = sum(T(f));
            sumtv = [sumtv; sumt0];
        elseif R.sizeOrT == 2,
            sumt0 = median(T(f));
            sumtv = [sumtv; sumt0];
        elseif R.sizeOrT == 3,
            sumt0 = min(T(f) .^ 2) * length(f);
            sumtv = [sumtv; sumt0];
        end;
        sumT(f) = sumt0;
    end;
    saveval = max(sumtv);
    if isnan(saveval),
        saveval = 0;
    end;
    maxBlobPower0 = saveval;
else
    maxBlobPower0 = 0;
end;
