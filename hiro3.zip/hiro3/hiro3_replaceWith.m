function hiro3_replaceWith(varargin)

global hiro3_mem;

answer = inputdlg('Values to replace', 'Value set, comma-separated');
if isempty(answer),
    return;
end;

toReplace = str2num(answer{1});
if isempty(toReplace),
    return;
end;

answer = inputdlg('Replace with value', 'Replace-value');
if isempty(answer),
    return;
end;

replaceVal = str2num(answer{1});
if isempty(replaceVal),
    return;
end;

for iLayer = 2:length(hiro3_mem.layers),
    fAll = [];
    for iTR = 1:length(toReplace),
        f = find(hiro3_mem.layers{iLayer}.data == toReplace(iTR));
        fAll = [fAll; f(:)];
    end;
    hiro3_mem.layers{iLayer}.data(fAll) = replaceVal;
end;

hiro3_redraw;
