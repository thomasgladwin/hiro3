function hiro3_remove_data(dum1, dum2, fileTypeStr)

global hiro3_mem;

iLayer = 0;
if strcmp(fileTypeStr, 'anatomy'),
    iLayer = 1;
elseif strcmp(fileTypeStr, 'functional'),
    % remove last non-empty functional layer
    x = 1;
    for iLayer = 2:length(hiro3_mem.layers),
        if ~isempty(hiro3_mem.layers{iLayer}.data),
            x = iLayer;
        end;
    end;
    iLayer = x;
    if iLayer <= 1,
        iLayer = 0;
    end;
end;
if iLayer == 0,
    return;
end;
hiro3_remove_data_inner(iLayer);
hiro3_redraw;

function hiro3_remove_data_inner(iLayer)

global hiro3_mem;

hiro3_init_layer(iLayer, 'empty');

% Reorganize windows if open
fid = gcf;
visible = get(hiro3_mem.fid_color_scheme_GUI, 'Visible');
hiro3_show_color_scheme_GUI(visible);
figure(fid);

% Forget changes
hiro3_mem.changes = {};
