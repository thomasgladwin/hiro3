function hiro3_init_layer(iLayer, typestring);

global hiro3_mem;

hiro3_mem.layers{iLayer}.filename = [];
hiro3_mem.layers{iLayer}.headerinfo = [];
hiro3_mem.layers{iLayer}.data = [];
hiro3_mem.layers{iLayer}.type = typestring;
hiro3_mem.layers{iLayer}.cutoff = 0;
hiro3_mem.layers{iLayer}.colormap = [];
hiro3_mem.layers{iLayer}.coords = [];
hiro3_mem.layers{iLayer}.xyz = [0 0 0]';
hiro3_mem.layers{iLayer}.min_BB = [];
hiro3_mem.layers{iLayer}.max_BB = [];
hiro3_mem.layers{iLayer}.color_id = 1;
hiro3_mem.layers{iLayer}.transparency = 0;
