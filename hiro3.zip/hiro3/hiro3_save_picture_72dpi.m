function hiro3_save_picture(varargin)

global hiro3_mem;

[filename, pathname] = uiputfile( ...
       {'*.tif'}, ...
        'Save as...');
filename = [pathname filename];
%hiro3_redraw;
set(gcf, 'PaperPositionMode', 'auto');
set(gcf, 'Renderer', 'opengl');
set(gcf, 'InvertHardcopy', 'off');

print( gcf, '-dtiff', '-r72', filename );
