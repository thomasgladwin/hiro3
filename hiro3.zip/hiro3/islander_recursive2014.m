function [L, info] = islander_recursive2014(Tin)

% [L, info] = islander_recursive2014(Tin)
%
% Thomas E. Gladwin (2015)

global T;
global L;
global LocMax;
global current_L_val;
global ir14fb;

ir14fb = 0;
T = Tin;
L = zeros(size(T));
clear('Tin');

% Only consider activation, or pos and neg
T(isnan(T)) = 0;
% T(T < 0) = 0;
T = abs(T);

% Get LocMax
LocMax = inner_get_LocMax(T);

current_L_val = 1;
while 1,
    
    ind0_hlm = inner_find_highest_local_max();
    if isempty(ind0_hlm),
        break;
    end;
    
    L(ind0_hlm) = current_L_val;
    inner_add_peak(ind0_hlm);
    
    f = find(L == current_L_val);
    if ir14fb == 1,
        fprintf(['Peak size = ' num2str(length(f)) '\n']);
    end;
    
    current_L_val = current_L_val + 1;
end;

% Merge blobs
% L = inner_merge_blobs(L);

% Trim edges
% L = inner_trim_edges(L);

% Get descriptive info
info = inner_get_info();

%%

function ind_hlm = inner_find_highest_local_max()
global T;
global L;
global LocMax;
global ir14fb;

fLocMax = find(LocMax(:) > 0 & L(:) == 0);
if ir14fb == 1,
    fprintf(['N of local maxima = ' num2str(length(fLocMax)) '\n']);
end;
[maxval, ind0] = max(T(fLocMax));
ind_hlm = fLocMax(ind0);

function inner_add_peak(ind0_hlm)
global T;
global Visited;
Visited = zeros(size(T));
recdepth = 0;
current_ind = ind0_hlm;
slope_history = [];
value_history = [];
[ix, iy, iz] = ind2sub(size(T), current_ind);
inner_cascade_recursive(ix, iy, iz, value_history, slope_history, ix, iy, iz, T(ix, iy, iz), 0);

function inner_cascade_recursive(ix, iy, iz, value_history, slope_history, ix0, iy0, iz0, valCentre, recdepth)
global L;
global T;
global current_L_val;
global Visited;
global ir14fb;

Visited(ix, iy, iz) = 1;

if ir14fb == 1,
    fprintf([num2str(current_L_val) '. ']);
    fprintf(['Depth: ' num2str(recdepth) '\n']);
end;

this_val = T(ix, iy, iz);

if this_val == 0 || isnan(this_val),
    recdepth = recdepth - 1;
    return;
end;

if ~isempty(value_history),
    this_slope = this_val - value_history(end);
else
    this_slope = NaN;
end;
if ir14fb == 1,
    fprintf(['\tVal = ' num2str(this_val), ' slope = ' num2str(this_slope) '\n']);
end;

% Check for stop conditions
stop_here = inner_check_for_stop(this_val, this_slope, value_history, slope_history);

% Add this voxel
if ir14fb == 1,
    fprintf(['\tAdding and continuing from voxel, at ' num2str([ix iy iz]) '\n']);
end;
if ~(this_val == 0 || isnan(this_val)),
    L(ix, iy, iz) = current_L_val;
end;

% Stop
if stop_here == 1,
    if ir14fb == 1,
        fprintf(['\tStopped at ' num2str([ix iy iz]) '\n']);
    end;
    recdepth = recdepth - 1;
    return;
end;

value_history = [value_history; this_val];
if ~isnan(this_slope),
    slope_history = [slope_history; this_slope];
end;

% Spread
for dx = [-1, 0, 1],
    for dy = [-1, 0, 1],
        for dz = [-1, 0, 1],
            ix2 = ix + dx;
            iy2 = iy + dy;
            iz2 = iz + dz;
            if abs(ix - ix2) + abs(iy - iy2) + abs(iz - iz2) == 0,
                continue;
            end;
            if min([ix2; iy2; iz2]) < 1,
                continue;
            end;
            if ix2 > size(T, 1) || iy2 > size(T, 2) || iz2 > size(T, 3),
                continue;
            end;
            if Visited(ix2, iy2, iz2) == 1,
                continue;
            end;
            if L(ix2, iy2, iz2) ~= 0,
                continue;
            end;
            if (T(ix2, iy2, iz2) <= 0),
                continue;
            end;
            dNew = sqrt((ix2 - ix0) ^ 2 + (iy2 - iy0) ^ 2 + (iz2 - iz0) ^ 2);
            dOld = sqrt((ix - ix0) ^ 2 + (iy - iy0) ^ 2 + (iz - iz0) ^ 2);
            if dNew < dOld,
                if ir14fb == 1,
                    %                         fprintf('\tPreventing double-back\n');
                end;
                continue;
            end;
            %             fprintf(['\tSearching ' num2str([dx dy dz]) '\n']);
            inner_cascade_recursive(ix2, iy2, iz2, value_history, slope_history, ix0, iy0, iz0, T(ix, iy, iz), recdepth + 1);
        end;
    end;
end;

function info = inner_get_info
global T;
global L;
u = unique(L(L ~= 0));
info.label = u;
info.N = length(u);
for iu = 1:length(u),
end;

function L0 = inner_merge_blobs(L0)
global T

u = unique(L0);
u(find(u == 0)) = [];

freevmem = {};

for iLabel = 1:length(u),
    label0 = u(1 + length(u) - iLabel);
    Edges = getEdges(L0 == label0);
    f = find(L0 == label0 & Edges == 1);
    adjacents = [];
    memory = [];
    freev = [];
    for ind00 = 1:length(f),
        ind0 = f(ind00);
        [x0, y0, z0] = ind2sub(size(L0), ind0);
        freestanding = 1;
        for dz = -1:1,
            zz = z0 + dz; if zz < 1 || zz > size(L0, 3), continue; end;
            for dy = -1:1;
                yy = y0 + dy; if yy < 1 || yy > size(L0, 2), continue; end;
                for dx = -1:1,
                    xx = x0 + dx; if xx < 1 || xx > size(L0, 1), continue; end;
                    if ~isempty(memory),
                        tester = abs(memory - [xx; yy; zz] * ones(1, size(memory, 2)));
                        tester = sum(tester);
                        ftester = find(tester == 0);
                        if length(ftester) > 0,
                            continue;
                        end;
                    end;
                    v1 = L0(xx, yy, zz);
                    if v1 == label0,
                        continue;
                    end;
                    memory = [memory [xx; yy; zz]];
                    adjacents = [adjacents; v1];
                    if v1~= 0,
                        freestanding = 0;
                    end;
                end;
            end;
        end;
        freev = [freev; freestanding];
    end;
    freevmem{iLabel} = adjacents;
    f0 = find(adjacents == 0);
    adjacents(f0) = [];
    ua = unique(adjacents);
    propFree = length(find(freev == 1)) / length(freev);
    if propFree < 0.5, % && length(ua) == 1, % check whether surrounded by or attached to one other cluster
        m0 = mode(adjacents);
        flabel0 = find(L0 == label0);
        L0(flabel0) = m0;
    end;
end;

function Edges = getEdges(T)
Edges = zeros(size(T));
[nx, ny, nz] = size(Edges);
for dx = -1:1,
    for dy = -1:1,
        for dz = -1:1,
            if abs(dx) + abs(dy) + abs(dz) == 0,
                continue;
            end;
            bx = 2 + dx;
            by = 2 + dy;
            bz = 2 + dz;
            bnx = bx + nx - 1;
            bny = by + ny - 1;
            bnz = bz + nz - 1;
            tmp = zeros(nx + 2, ny + 2, nz + 2);
            tmp(bx:bnx, by:bny, bz:bnz) = T;
            tmp = tmp(2:(end - 1), 2:(end - 1), 2:(end - 1));
            Edges = Edges | (T > 0 & tmp == 0);
        end;
    end;
end;

function L = inner_trim_edges(L)
uL = unique(L(:));
uL(uL == 0) = [];
for iUL = 1:length(uL),
    Edges = getEdges(L == uL(iUL));
    f = find(Edges);
    L(f) = 0;
end;

function LocMax = inner_get_LocMax(T)

LocMax = ones(size(T));
[nx, ny, nz] = size(LocMax);
for dx = -1:1,
    for dy = -1:1,
        for dz = -1:1,
            if abs(dx) + abs(dy) + abs(dz) == 0,
                continue;
            end;
            bx = 2 + dx;
            by = 2 + dy;
            bz = 2 + dz;
            bnx = bx + nx - 1;
            bny = by + ny - 1;
            bnz = bz + nz - 1;
            tmp = zeros(nx + 2, ny + 2, nz + 2);
            tmp(bx:bnx, by:bny, bz:bnz) = T;
            tmp = tmp(2:(end - 1), 2:(end - 1), 2:(end - 1));
            LocMax = LocMax & T > tmp;
        end;
    end;
end;

function stop_here = inner_check_for_stop(this_val, this_slope, value_history, slope_history)
stop_here = 0;
if length(slope_history) < 2,
    return;
end;
if ~isempty(value_history) && ~isnan(this_slope) && ~isempty(slope_history),
    critv = [this_slope; slope_history(:)];
    crit0 = length(find(critv >= 0)) / length(critv);
    if crit0 > 0.1,
        stop_here = 1;
    end;
end;
