function MREYE

% MREYE visualization program, for resliced data only.

disp('MREYE, version 1.0, Thomas E. Gladwin, Matthijs Vink (2008).');
addpath /mnt/home/thomas/matlab/fMRI/hiro3/stable_version
hiro3
