function label = hiro3_get_BA(xyz)

global hiro3_mem;

% label = 'Unlabeled';
% 
% min0 = min(hiro3_mem.template.xyz');
% max0 = max(hiro3_mem.template.xyz');
% subs_in_template = ceil(size(hiro3_mem.template.data)' .* (xyz(:) - min0(:)) ./ (max0(:) - min0(:)));
% label = 'No_label';
% legal = 1;
% for n = 1:3,
%     if subs_in_template(n) <= 0 || subs_in_template(n) > size(hiro3_mem.template.data, n),
%         legal = 0;
%     end;
% end;
% if legal == 1,
%     template_id = hiro3_mem.template.data(subs_in_template(1), subs_in_template(2), subs_in_template(3));
%     if template_id > 0,
%         label = hiro3_mem.template.labels{template_id};
%     end;
% else
%     % Find nearest label: work in progress
% end;

d = (hiro3_mem.templateBrodmann.xyz - xyz(:) * ones(1, size(hiro3_mem.templateBrodmann.xyz, 2))) .^ 2;
d = sum(d);
[sorted, indices] = sort(d);
label = 'Unlabeled';
for n = 1:length(indices),
    ind0 = indices(n);
    template_id = hiro3_mem.templateBrodmann.data(ind0);
    if template_id > 0,
        label = num2str(template_id);
        break;
    end;
end;
