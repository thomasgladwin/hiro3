function hiro3_popup_message(txt);

axid = hiro3_popup_message_on(txt);
pause(0.5);
hiro3_popup_message_off(axid);
