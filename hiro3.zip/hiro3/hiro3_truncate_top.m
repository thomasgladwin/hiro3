function hiro3_truncate_top(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 1,
    return;
end;

answer=inputdlg('Percentage to truncate','Truncate top percentage',1,{'25'});
try,
    perc = str2num(answer{1});
catch,
    return;
end;
if isempty(perc),
    return;
end;

hiro3_truncate_top_inner(perc);
hiro3_redraw;
