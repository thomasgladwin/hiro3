function hiro3_permtest_2group_clustersize_rerun(varargin)

global hiro3_mem;

if isempty(hiro3_mem.previous_filenames),
    return;
end;

filenames = hiro3_mem.previous_filenames;
[p0, bn] = fileparts(filenames{1}{1});

disp('Running...');
hiro3_mem.R_permtest = permtest_getSumTForTops_2groups(filenames, 200, 0, ['hiro3_permtest_' bn '.nii'], 0);
disp('Complete. Send h3data to workspace to get information.');
