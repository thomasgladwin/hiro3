function iLayer = hiro3_last_layer

global hiro3_mem;

x = 0;
for iLayer = 1:length(hiro3_mem.layers),
    if ~isfield(hiro3_mem.layers{iLayer}, 'data'),
        continue;
    end;
    if isempty(hiro3_mem.layers{iLayer}.data),
        continue;
    end;
    x = iLayer;
end;
iLayer = x;
