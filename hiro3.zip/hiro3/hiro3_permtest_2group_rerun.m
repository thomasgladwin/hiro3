function hiro3_permtest_2group(varargin)

global hiro3_mem;

if isempty(hiro3_mem.previous_filenames),
    return;
end;

filenames = hiro3_mem.previous_filenames;
[p0, bn] = fileparts(filenames{1}{1});

hiro3_mem.R_permtest = permtest_getSumTForTops_2groups(filenames, 100, 1, ['hiro3_permtest_' bn '.nii'], 0);
