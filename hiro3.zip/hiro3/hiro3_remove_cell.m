function hiro3_remove_cell(winid)

global hiro3_mem;

if hiro3_mem{winid}.linked > 0,
    hiro3_mem{hiro3_mem{winid}.linked}.linked = 0;
end;
hiro3_mem{winid} = {};
hiro3_mem{winid}.fid = 0;
hiro3_mem{winid}.linked = 0;
