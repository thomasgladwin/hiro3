function hiro3_MNI_report_toggle(varargin)

global hiro3_mem winid;

for n = 1:length(hiro3_mem),
    if hiro3_mem{n}.fid == gcf,
        winid = n;
    end;
end;

hiro3_mem{winid}.report_toggle = mod(hiro3_mem{winid}.report_toggle + 1, 2);

hiro3_redraw;
