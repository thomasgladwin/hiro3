function hiro3_fillPlotMatrix()

global hiro3_mem winid;

% pos
if ~isempty(hiro3_mem{winid}.data{2}),
    norm_func = hiro3_mem{winid}.data{2};
    hiro3_mem{winid}.normMaxOrig = max(norm_func(:));
    cut0 = min(hiro3_mem{winid}.cutoff, hiro3_mem{winid}.normMaxOrig);
    if hiro3_mem{winid}.cutoff < hiro3_mem{winid}.normMaxOrig,
        norm_func = (1 - hiro3_mem{winid}.plotBuffer) * (norm_func - cut0) / (hiro3_mem{winid}.normMaxOrig - cut0);
    else,
        norm_func = 0;
    end;
    norm_func(find(norm_func < 0)) = 0;
else,
    norm_func = zeros(size(hiro3_mem{winid}.data{1}));
end;
% neg
if ~isempty(hiro3_mem{winid}.data{2}),
    norm_func_neg = -hiro3_mem{winid}.data{2};
    hiro3_mem{winid}.normMaxOrig_neg = max(norm_func_neg(:));
    cut0 = min(hiro3_mem{winid}.cutoff, hiro3_mem{winid}.normMaxOrig_neg);
    if hiro3_mem{winid}.cutoff < hiro3_mem{winid}.normMaxOrig_neg,
        norm_func_neg = (1 - hiro3_mem{winid}.plotBuffer) * (norm_func_neg - cut0) / (hiro3_mem{winid}.normMaxOrig_neg - cut0);
    else,
        norm_func_neg = 0;
    end;
    norm_func_neg(find(norm_func_neg < 0)) = 0;
else,
    norm_func_neg = zeros(size(hiro3_mem{winid}.data{1}));
end;
if ~isempty(hiro3_mem{winid}.data{1}),
    hiro3_mem{winid}.plotMatrix = hiro3_mem{winid}.data{1};
    f = find(norm_func > 0);
    hiro3_mem{winid}.plotMatrix(f) = 1 + norm_func(f);
    f = find(norm_func_neg > 0);
    hiro3_mem{winid}.plotMatrix(f) = 2 + norm_func_neg(f);
else,
    hiro3_mem{winid}.plotMatrix = zeros(size(norm_func));
    f = find(norm_func > 0);
    hiro3_mem{winid}.plotMatrix(f) = 1 + norm_func(f);
    f = find(norm_func_neg > 0);
    hiro3_mem{winid}.plotMatrix(f) = 2 + norm_func_neg(f);
end;
