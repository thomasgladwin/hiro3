function hiro3_make_outline(varargin)

global hiro3_mem;

iLayer = hiro3_last_layer;
if iLayer < 2,
    return;
end;
if isempty(hiro3_mem.layers{1}.data),
    fprintf('Load an anatomy as a reference for reslicing.');
    return;
end;

axid = hiro3_popup_message_on('Making outline...');

% Create interpolated functional layer F
xf = unique(hiro3_mem.layers{iLayer}.xyz(1, :));
yf = unique(hiro3_mem.layers{iLayer}.xyz(2, :));
zf = unique(hiro3_mem.layers{iLayer}.xyz(3, :));
[Xf,Yf,Zf] = meshgrid(yf,xf,zf);
xa = unique(hiro3_mem.layers{1}.xyz(1, :));
ya = unique(hiro3_mem.layers{1}.xyz(2, :));
za = unique(hiro3_mem.layers{1}.xyz(3, :));
[Xa,Ya,Za] = meshgrid(ya,xa,za);
F = interp3(Xf, Yf, Zf, hiro3_mem.layers{iLayer}.data, Xa, Ya, Za);

cutoff = varargin{end};
F(find(abs(F) <= cutoff)) = 0;
F(find(F)) = 1;

for z = 1:size(F, 3),
    plane = squeeze(F(:, :, z));
    p00 = plane(2:(end - 1), 2:(end - 1));
    pn0 = plane(1:(end - 2), 2:(end - 1));
    p0n = plane(2:(end - 1), 1:(end - 2));
    sh1 = abs(p00 - pn0);
    sh2 = abs(p00 - p0n);
    sh = sh1 + sh2;
    sh(find(sh)) = 1;
    F(:, :, z) = 0;
    F(2:(end - 1), 2:(end - 1), z) = sh;
end;

% Replace necessary hiro3_mem and header info
old_coords = hiro3_mem.layers{iLayer}.coords;
index0 = sub2ind(size(hiro3_mem.layers{iLayer}.data), old_coords(1), old_coords(2), old_coords(3));
old_xyz = hiro3_mem.layers{iLayer}.xyz(:, index0);

hiro3_mem.layers{iLayer}.data = F;
hiro3_mem.layers{iLayer}.xyz = hiro3_mem.layers{1}.xyz;
old_fname = hiro3_mem.layers{iLayer}.headerinfo.fname;
hiro3_mem.layers{iLayer}.headerinfo = hiro3_mem.layers{1}.headerinfo;
hiro3_mem.layers{iLayer}.headerinfo.fname = old_fname;
hiro3_mem.layers{iLayer}.min_BB = hiro3_mem.layers{1}.min_BB;
hiro3_mem.layers{iLayer}.max_BB = hiro3_mem.layers{1}.max_BB;

for n = 1:3,
    % Proportional xyz coords to voxel coords.
    max_BB0 = hiro3_mem.layers{iLayer}.max_BB(n);
    min_BB0 = hiro3_mem.layers{iLayer}.min_BB(n);
    vox = ceil( (old_xyz(n) - min_BB0) / (max_BB0 - min_BB0) * size(hiro3_mem.layers{iLayer}.data, n) );
    hiro3_mem.layers{iLayer}.coords(n) = vox;
    % Prevent overflow
    if hiro3_mem.layers{iLayer}.coords(n) <= 0,
        hiro3_mem.layers{iLayer}.coords(n) = 1;
    end;
    if hiro3_mem.layers{iLayer}.coords(n) > size(hiro3_mem.layers{iLayer}.data, n),
        hiro3_mem.layers{iLayer}.coords(n) = size(hiro3_mem.layers{iLayer}.data, n);
    end;
end;

% Replot
hiro3_mem.layers{iLayer}.cutoff = 0.5;
hiro3_mem.layers{iLayer}.color_id = 2;

hiro3_popup_message_off(axid);

hiro3_redraw;
