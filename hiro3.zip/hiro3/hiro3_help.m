function hiro3_help(varargin)

fprintf('Welcome to Hiro3 (TE Gladwin, M Vink, RB Mars, 2016, MethodsX).\n');
fprintf('* * *\nSPM5 functions have to be in the path.\n* * *\n');
fprintf('* * *\nHiro3 is intended for use with resliced data.\n* * *\n');
fprintf('\nKeyboard commands:\n');
fprintf('Press C to enter an activation cutoff.\n');
fprintf('Press J to jump to a label.\n');
fprintf('Press space to toggle navigation and replace-value mode.\n');
fprintf('Press - to undo changes.\n');
fprintf('Press R to set a new replace-value.\n');
fprintf('Press i to display data information.\n');
fprintf('\nFor correct overlay positioning\n');
fprintf('\tthe orientations must be equal, or the images must be centered around zero.\n');
fprintf('\nVolumes are plotted with increasing voxel-index from left to right.\n');
fprintf('\nAnatomical information is based on the standard MNI map.\n');
fprintf('MNI info will only be valid if the data have the same orientation!\n');
