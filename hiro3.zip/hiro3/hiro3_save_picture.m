function hiro3_save_picture(varargin)

global hiro3_mem;

fn = hiro3_mem.layers{2}.filename;
fn = [fn(1:(end - 2)) '.tif'];
[filename, pathname] = uiputfile( ...
       {'*.tif'}, ...
        'Save as...', fn);
filename = [pathname filename];
%hiro3_redraw;
set(gcf, 'PaperPositionMode', 'auto');
set(gcf, 'Renderer', 'opengl');
set(gcf, 'InvertHardcopy', 'off');

print( gcf, '-dtiff', '-r600', filename );
