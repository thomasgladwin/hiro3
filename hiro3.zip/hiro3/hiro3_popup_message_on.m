function axid = hiro3_popup_message_on(txt);

axid = axes('position', [0.1, 0.4, 0.8, 0.2]);
fill([0 0 1 1], [0 1 1 0], [0.95 0.95 0.95]); hold on;
bh = 0.02;
bv = (0.8 / 0.2) * bh;
l = line([bh bh], [bv 1 - bv]);
set(l, 'Color', [0 0 0]);
l = line([bh 1 - bh], [1 - bv 1 - bv]);
set(l, 'Color', [0 0 0]);
l = line([1 - bh 1 - bh], [1 - bv bv]);
set(l, 'Color', [0 0 0]);
l = line([1 - bh bh], [bv bv]);
set(l, 'Color', [0 0 0]);

t = text(0.01, 0.5, txt);
set(t, 'Color', [0 0 0]);
e = get(t, 'Extent');
p = get(t, 'Position');
p(1) = 0.5 - e(3) / 2;
set(t, 'Position', p);
axis off;

refresh;
pause(0.01);
