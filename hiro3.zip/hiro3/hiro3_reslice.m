function hiro3_reslice(varargin)

global hiro3_mem winid;

set1 = varargin{1};
set2 = varargin{2};
if isempty(hiro3_mem{winid}.data{set1}) || isempty(hiro3_mem{winid}.data{set2}),
    return;
end;
hiro3_mem{winid}.data{set1} = interp3(hiro3_mem{winid}.X{set1}, hiro3_mem{winid}.Y{set1}, hiro3_mem{winid}.Z{set1}, hiro3_mem{winid}.data{set1}, hiro3_mem{winid}.X{set2}, hiro3_mem{winid}.Y{set2}, hiro3_mem{winid}.Z{set2}, 'nearest');
hiro3_mem{winid}.X{set1} = hiro3_mem{winid}.X{set2};
hiro3_mem{winid}.Y{set1} = hiro3_mem{winid}.Y{set2};
hiro3_mem{winid}.Z{set1} = hiro3_mem{winid}.Z{set2};
