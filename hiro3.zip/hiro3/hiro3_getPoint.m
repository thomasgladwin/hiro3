function hiro3_getPoint

global hiro3_mem;

mousePos = get(gca, 'CurrentPoint');
x = mousePos(1, 2);
y = mousePos(1, 1);

%disp([x y]);

clicked_view = find(gca == hiro3_mem.ax0);
if isempty(clicked_view),
    return;
end;
if clicked_view > 3,
    return;
end;
hiro3_mem.active_dimension = clicked_view;
% Get dimensions to adjust
d = [1 2 3];
d(hiro3_mem.active_dimension) = [];

for iLayer = 1:length(hiro3_mem.layers),
    if isfield(hiro3_mem.layers{iLayer}, 'data'),
        if isempty(hiro3_mem.layers{iLayer}.data),
            continue;
        end;
    end;
    % Proportional xyz coords to voxel coords.
    max_BB0 = hiro3_mem.layers{iLayer}.max_BB;
    max_BB0(hiro3_mem.active_dimension) = [];
    min_BB0 = hiro3_mem.layers{iLayer}.min_BB;
    min_BB0(hiro3_mem.active_dimension) = [];
    % Get voxel coordinates
    vox(1) = ceil( (y - min_BB0(1)) / (max_BB0(1) - min_BB0(1)) * size(hiro3_mem.layers{iLayer}.data, d(1)) );
    vox(2) = ceil( (x - min_BB0(2)) / (max_BB0(2) - min_BB0(2)) * size(hiro3_mem.layers{iLayer}.data, d(2)) );
    hiro3_mem.layers{iLayer}.coords([d(1), d(2)]) = [vox(1) vox(2)];
    % Prevent overflow
    for n = 1:3,
        if hiro3_mem.layers{iLayer}.coords(n) <= 0,
            hiro3_mem.layers{iLayer}.coords(n) = 1;
        end;
        if hiro3_mem.layers{iLayer}.coords(n) > size(hiro3_mem.layers{iLayer}.data, n),
            hiro3_mem.layers{iLayer}.coords(n) = size(hiro3_mem.layers{iLayer}.data, n);
        end;
    end;
end;
