function hiro3_mouseUp(dum1, dum2)

global hiro3_mem;
