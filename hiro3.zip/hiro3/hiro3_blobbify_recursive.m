function hiro3_blobbify_recursive(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 2,
    fprintf('Please load an activation map.\n');
    return;
elseif isempty(hiro3_mem.layers{2}.data),
    fprintf('Please load an activation map.\n');
    return;
end;

[savename, pathname] = uiputfile( ...
    {'*.nii'}, ...
    'Save label map as...');
if savename == 0,
    return;
end;

axid = hiro3_popup_message_on('Defining clusters...');

[dum, base0, ext] = fileparts(savename);
[L, info] = hiro3_islander_recursive(hiro3_mem.layers{2}.data, hiro3_mem.cutoff);
% info = hiro3_saveIslInfo([pathname '/' base0 '.txt'], info);
LH = hiro3_mem.layers{2}.headerinfo;
LH.fname = [pathname savename];
if isempty(ext),
    LH.fname = [LH.fname '.nii'];
end;
spm_write_vol(LH, L);

hiro3_popup_message_off(axid);

hiro3_redraw;
