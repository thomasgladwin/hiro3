function O = hiro3_labelMaker(M)

% function O = hiro3_labelMaker(M)
%
% M is een matrix met per rij de x, y, en z coordinaten in mm

[p] = fileparts(which('hiro3_labelMaker'));
filename = [p '/raal_MNI_V4.img'];
O.template.headerinfo = spm_vol(filename);
[O.template.data, O.template.xyz] = spm_read_vols(O.template.headerinfo);
O.template.data = flipdim(O.template.data, 1);
file = fopen([p '/aal_MNI_V4.txt']);
n = 1;
while ~feof(file),
    O.template.labels{n} = fgetl(file);
    n = n + 1;
end;
fclose(file);
filename = [p '/TD_brodmann.img'];
O.templateBrodmann.headerinfo = spm_vol(filename);
[O.templateBrodmann.data, O.templateBrodmann.xyz] = spm_read_vols(O.templateBrodmann.headerinfo);

for iLoc = 1:size(M, 1),
    xyz = M(iLoc, :);
    d = (O.template.xyz - xyz(:) * ones(1, size(O.template.xyz, 2))) .^ 2;
    d = sqrt(sum(d));
    [sorted, indices] = sort(d);
    label = 'Unlabeled';
    for n = 1:length(indices),
        ind0 = indices(n);
        template_id = O.template.data(ind0);
        if template_id > 0,
            label = O.template.labels{template_id};
            break;
        end;
    end;
    O.label{iLoc} = label;
    O.distance(iLoc) = d(ind0);
end;

for iLoc = 1:size(M, 1),
    fprintf([num2str(iLoc) ' (' num2str(M(iLoc, :)) ')\t']);
    fprintf([O.label{iLoc} '\tdistance = ' num2str(O.distance(iLoc)) ' mm\n']);
end;
