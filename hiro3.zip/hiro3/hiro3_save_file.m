function hiro3_save_file(varargin)

global hiro3_mem;

% Find last non-empty functional layer
x = 0;
for iLayer = 2:length(hiro3_mem.layers),
    if ~isempty(hiro3_mem.layers{iLayer}.data),
        x = iLayer;
    end;
end;
iLayer = x;
if iLayer == 0,
    return;
end;
[filename, pathname] = uiputfile('*.nii;*.img', 'Save as...', hiro3_mem.layers{iLayer}.headerinfo.fname);
cd0 = pwd;
cd(pathname);
headerinfo = hiro3_mem.layers{iLayer}.headerinfo;
headerinfo.fname = filename;
spm_write_vol(headerinfo, hiro3_mem.layers{iLayer}.data);
cd(cd0);
