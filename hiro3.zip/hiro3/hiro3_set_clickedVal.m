function hiro3_set_clickedVal(winid)

global hiro3_mem;

if ~isempty(hiro3_mem{winid}.data{2}),
    try,
        val = hiro3_mem{winid}.plotMatrix(hiro3_mem{winid}.slice(1), hiro3_mem{winid}.slice(2), hiro3_mem{winid}.slice(3));
    catch,
        val = 0;
    end;
    if val > 2,
        Denom = (hiro3_mem{winid}.normMaxOrig_neg - hiro3_mem{winid}.cutoff);
        valsign = -1;
        val = val - 2;
    elseif val > 1,
        Denom = (hiro3_mem{winid}.normMaxOrig - hiro3_mem{winid}.cutoff);
        valsign = 1;
        val = val - 1;
    else,
        hiro3_mem{winid}.clickedVal = 0;
        valsign = 0;
        Denom = 1;
    end;
    val = val * (1 / (1 - hiro3_mem{winid}.plotBuffer));
    val = val * Denom;
    val = val + hiro3_mem{winid}.cutoff;
    val = val * valsign;
    hiro3_mem{winid}.clickedVal = val;
    if hiro3_mem{winid}.labelData == 1,
        hiro3_mem{winid}.clickedVal = floor(hiro3_mem{winid}.clickedVal + 0.5);
    end;
end;
