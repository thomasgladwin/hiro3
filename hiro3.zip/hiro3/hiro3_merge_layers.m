function hiro3_merge_layers(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 3,
    return;
end;
if isempty(hiro3_mem.layers{2}.data) || isempty(hiro3_mem.layers{3}.data),
    return;
end;
if sum(abs(size(hiro3_mem.layers{2}.data) - size(hiro3_mem.layers{3}.data))) > 0,
    fprintf('Merging can only applied when layers have equal dimensions.\n');
    return;
end;

tmp = zeros(size(hiro3_mem.layers{2}.data));
for iLayer = 2:length(hiro3_mem.layers),
    fextr = find(abs(hiro3_mem.layers{iLayer}.data) > abs(tmp));
    tmp(fextr) = hiro3_mem.layers{iLayer}.data(fextr);
end;

for iLayer = 3:length(hiro3_mem.layers),
    hiro3_remove_data(0, 0, 'functional');
end;

hiro3_mem.layers{2}.data = tmp;

clear tmp;

hiro3_redraw;
