function activation_movie(varargin)

% function act_mov_struct = activation_movie([filenames from spm_select, downsample])
%
% If something goes wrong, close and kill everything with:
% delete(gcf); out = timerfindall; delete(out);
%
% By default, data will be downsampled for plotting speed and memory. Call
% with 0 as only or second argument to plot in original resolution.
%
% Filename parsing assumes filenames of the form XYZ1, XYZ2, ..., XYZ10,
% etc, or of the form XYZ0001, XYZ0002, ..., XYZ0010, etc.
%
% Click on the different plot types for things to happen.
%
% Thomas Gladwin, 2015

filesarg = 1;
downsample0 = 1;
if isempty(varargin),
    filesarg = 0;
else,
    if ~ischar(varargin{1}),
        filesarg = 0;
        downsample0 = varargin{1};
    else,
        if length(varargin) > 1,
            downsample0 = varargin{2};
        end;
    end;
end;
if filesarg == 0,
    filenames_spm_select = spm_select(Inf, 'image', 'Select file', [], pwd);
else,
    filenames_spm_select = varargin{1};
end;
if isempty(filenames_spm_select),
    return;
end;
scan_nums = [];
filenames_initial = {};
for n = 1:size(filenames_spm_select, 1),
    filenames_initial{n} = filenames_spm_select(n, :);
    [p0, bn] = fileparts(filenames_initial{n});
    chars = 1:length(bn);
    digits = regexp(bn, '\d');
    chars(digits) = [];
    final_letter = chars(end);
    digits(digits <= final_letter) = [];
    this_scan_num = str2num(bn(digits));
    scan_nums = [scan_nums; this_scan_num];
end;
[sorted, ind0] = sort(scan_nums, 'ascend');
for n = 1:length(filenames_initial),
    filenames{n} = filenames_initial{ind0(n)};
end;

global act_mov_struct
% act_mov_struct = rmfield(act_mov_struct, fieldnames(act_mov_struct));
act_mov_struct.ix = 1;
act_mov_struct.ix_to_load = 1;
act_mov_struct.ix_to_load_offset = 1;
act_mov_struct.d_ix_to_load = 10;
act_mov_struct.D4 = [];
act_mov_struct.x = filenames;
act_mov_struct.closeWindowReq = 0;
act_mov_struct.plotSelectedTime = 0;
act_mov_struct.sweep0_start = 0.5;
act_mov_struct.sweep0_end = 0.5;
act_mov_struct.d_sweep0 = 1;
act_mov_struct.sweep0 = act_mov_struct.sweep0_start;
act_mov_struct.x_loaded = zeros(size(act_mov_struct.x));
act_mov_struct.x_loaded_at_last_summary = act_mov_struct.x_loaded;
act_mov_struct.mode_time = 0;
act_mov_struct.mode_space = 0;
act_mov_struct.fid = figure;
act_mov_struct.plotCollapse = 1;
act_mov_struct.downsample = downsample0;
act_mov_struct.nViews = 4;
act_mov_struct.views = {};
act_mov_struct.viewLabels = {'Max', 'Slice', 'Variance', 'Max flatness'};
act_mov_struct.nTimecourses = 2;
act_mov_struct.timecourses = {};
act_mov_struct.origDim = [];
act_mov_struct.downDim = [30, 30, 30];

for iView = 1:act_mov_struct.nViews,
    for iDim = 1:3,
        for iVol = 1:length(act_mov_struct.x),
            act_mov_struct.views{iView, iDim}.toplot{iVol} = [];
        end;
        act_mov_struct.views{iView, iDim}.minVal = Inf;
        act_mov_struct.views{iView, iDim}.maxVal = -Inf;
    end;
end;
for iTimecourse = 1:act_mov_struct.nTimecourses,
    act_mov_struct.timecourses{iTimecourse}.curve = [];
end;

if isempty(act_mov_struct.x)
    fprintf('No files found.\n');
    return;
end;

inner_setup_fig;
inner_setup_control_areas;

set(act_mov_struct.fid, 'CloseRequestFcn', @inner_close_window);

act_mov_struct.t = timer;
act_mov_struct.t.Period = 0.02;
act_mov_struct.t.TasksToExecute = Inf;
act_mov_struct.t.ExecutionMode = 'fixedSpacing';
act_mov_struct.t.TimerFcn = @(myTimerObj, thisEvent)show_next_volume;

act_mov_struct.tL = timer;
act_mov_struct.tL.Period = 0.02;
act_mov_struct.tL.TasksToExecute = Inf;
act_mov_struct.tL.ExecutionMode = 'fixedSpacing';
act_mov_struct.tL.TimerFcn = @(myTimerObj, thisEvent)load_next_volume;

act_mov_struct.tC = timer;
act_mov_struct.tC.Period = 0.02;
act_mov_struct.tC.TasksToExecute = Inf;
act_mov_struct.tC.ExecutionMode = 'fixedSpacing';
act_mov_struct.tC.TimerFcn = @(myTimerObj, thisEvent)calculate_matrices;

start(act_mov_struct.tL);
start(act_mov_struct.tC);
start(act_mov_struct.t);

function inner_setup_fig
global act_mov_struct;
clf(act_mov_struct.fid);
act_mov_struct.axis_id = [];
act_mov_struct.nPos = 1;
act_mov_struct.nSP_images = 3;
iAxes = 1;
for iView = 1:3,
    sp = subplot(3, 3, iView);
    act_mov_struct.axis_id = [act_mov_struct.axis_id; sp];
end;
for iSummary = 1:2,
    iSP = 1 + iSummary;
    sp = subplot(3, 1, iSP);
    act_mov_struct.axis_id = [act_mov_struct.axis_id; sp];
end;

function inner_setup_control_areas
global act_mov_struct;
for iAxes = 1:length(act_mov_struct.axis_id)
    pos0 = get(act_mov_struct.axis_id(iAxes), 'Position');
    a = axes;
    set(a, 'Position', pos0);
    inner_setup_axes(a, iAxes);
end;

function inner_setup_axes(a, iAxes)
set(a, 'ButtonDownFcn', {@inner_on_click, iAxes});
set(a, 'NextPlot', 'replacechildren');
set(a, 'Color', 'none');
set(a, 'XTick', []);
set(a, 'YTick', []);

function inner_on_click(varargin)
global act_mov_struct;
clicked_axis = varargin{end};
mousePos = get(gca, 'CurrentPoint');
x = mousePos(1, 1);
x = min(1, max(0, x));
y = mousePos(1, 2);
if clicked_axis <= act_mov_struct.nSP_images,
    inner_change_mode_space(x);
else,
    act_mov_struct.mode_time = mod(act_mov_struct.mode_time + 1, 2);
    if act_mov_struct.mode_time == 1,
        act_mov_struct.mode_space = 0; % Set to 0, will be updated to 1 in change function
        inner_change_mode_space(x);
    end;
    inner_change_mode_time(x);
end;

function inner_change_mode_time(x)
global act_mov_struct;
if act_mov_struct.mode_time == 0,
    act_mov_struct.plotSelectedTime = 0;
else,
    ind0 = x * length(act_mov_struct.x);
    act_mov_struct.plotSelectedTime = min(length(act_mov_struct.x), max(1, round(ind0)));
end;

function inner_change_mode_space(x)
global act_mov_struct;
if act_mov_struct.mode_time == 0,
    act_mov_struct.mode_space = mod(act_mov_struct.mode_space + 1, act_mov_struct.nViews);
    if act_mov_struct.mode_space == 0,
        act_mov_struct.plotCollapse = 1;
        act_mov_struct.sweep0_start = act_mov_struct.sweep0;
        act_mov_struct.d_sweep0 = 1;
    elseif act_mov_struct.mode_space == 1,
        act_mov_struct.plotCollapse = 0;
        act_mov_struct.sweep0_start = act_mov_struct.sweep0;
        act_mov_struct.d_sweep0 = 1;
    elseif act_mov_struct.mode_space == 2,
        act_mov_struct.plotCollapse = 2; % Variance
        act_mov_struct.sweep0_start = act_mov_struct.sweep0;
        act_mov_struct.d_sweep0 = 1;
    elseif act_mov_struct.mode_space == 3,
        act_mov_struct.plotCollapse = 3; % Mean Vol-Vol Difference
        act_mov_struct.sweep0_start = act_mov_struct.sweep0;
        act_mov_struct.d_sweep0 = 1;
    elseif act_mov_struct.mode_space == 4,
        act_mov_struct.plotCollapse = 4; % similarity to neighbour
        act_mov_struct.sweep0_start = act_mov_struct.sweep0;
        act_mov_struct.d_sweep0 = 1;
    end;
else,
    act_mov_struct.mode_space = mod(act_mov_struct.mode_space + 1, 2);
    if act_mov_struct.mode_space == 1,
        act_mov_struct.plotCollapse = 0;
        act_mov_struct.sweep0_start = act_mov_struct.sweep0;
        act_mov_struct.d_sweep0 = 1;
    else,
        act_mov_struct.plotCollapse = 0;
        act_mov_struct.sweep0_start = 0.0;
        act_mov_struct.sweep0_end = 1.0;
        [nt, nx, ny, nz] = size(act_mov_struct.D4);
        maxdim = max([nx; ny; nz]);
        act_mov_struct.d_sweep0 = 1 / maxdim;
        xlim0 = max(xlim);
        if x < 0.5,
            act_mov_struct.d_sweep0 = -act_mov_struct.d_sweep0;
        end;
    end;
end;

function inner_close_window(hObject, callbackdata)
global act_mov_struct
act_mov_struct.closeWindowReq = 1;

function inner_final_close_window
global act_mov_struct;
if strcmp(act_mov_struct.tL.Running, 'on') == 1,
    stop(act_mov_struct.tL);
end;
if strcmp(act_mov_struct.tC.Running, 'on') == 1,
    stop(act_mov_struct.tC);
end;
delete(act_mov_struct.tL);
delete(act_mov_struct.t);
delete(act_mov_struct.tC);
delete(gcf);

function load_next_volume
global act_mov_struct;
H = spm_vol(act_mov_struct.x{act_mov_struct.ix_to_load});
act_mov_struct.origDim = H.dim;
D = inner_read_and_resize(H);
if isempty(act_mov_struct.D4),
    [nx, ny, nz] = size(D);
    act_mov_struct.D4 = zeros(length(act_mov_struct.x), nx, ny, nz);
    act_mov_struct.D4(1, :, :, :) = D;
else,
    act_mov_struct.D4(act_mov_struct.ix_to_load, :, :, :) = D;
end;
act_mov_struct.x_loaded(act_mov_struct.ix_to_load) = 1;
act_mov_struct.ix_to_load = act_mov_struct.ix_to_load + act_mov_struct.d_ix_to_load;
if act_mov_struct.ix_to_load > length(act_mov_struct.x),
    act_mov_struct.ix_to_load_offset = act_mov_struct.ix_to_load_offset + 1;
    act_mov_struct.ix_to_load = act_mov_struct.ix_to_load_offset;
end;
if act_mov_struct.closeWindowReq == 1 || act_mov_struct.ix_to_load_offset > min(act_mov_struct.d_ix_to_load, length(act_mov_struct.x)),
    stop(act_mov_struct.tL);
end;

function D = inner_read_and_resize(H)
global act_mov_struct;
if act_mov_struct.downsample == 0,
    D = spm_read_vols(H);
else,
    origvox = H.dim;
    vox = act_mov_struct.downDim;
    xMat = linspace(1, origvox(1), vox(1))' * ones(1, vox(2));
    yMat = ones(vox(1), 1) * linspace(1, origvox(2), vox(2));
    D = zeros(vox);
    for iSlice = 1:vox(3),
        zSlice = 1 + (iSlice - 1) * origvox(3) / vox(3);
        zMat = ones(vox(1), vox(2)) * zSlice;
        v = spm_sample_vol(H, xMat, yMat, zMat, 1);
        D(:, :, iSlice) = v;
    end;
end;

function show_next_volume
global act_mov_struct;
if isempty(find(act_mov_struct.x_loaded)),
    return;
end;

figure(act_mov_struct.fid);
iAxes = 1;

if act_mov_struct.plotSelectedTime > 0,
    act_mov_struct.ix = act_mov_struct.plotSelectedTime;
end;
while act_mov_struct.x_loaded(act_mov_struct.ix) == 0,
    act_mov_struct.ix = 1 + mod(act_mov_struct.ix, length(act_mov_struct.x_loaded));
end;
volume_to_plot = act_mov_struct.ix;

for iDim = 1:3,
    v{1} = 1:size(act_mov_struct.D4, 2);
    v{2} = 1:size(act_mov_struct.D4, 3);
    v{3} = 1:size(act_mov_struct.D4, 4);
    slice0 = 1 + floor((size(act_mov_struct.D4, iDim + 1) - 1) * act_mov_struct.sweep0);
    v{iDim} = slice0;
    if act_mov_struct.plotCollapse > 0 && ~isempty(act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.toplot{volume_to_plot}),
        toplot = act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.toplot{volume_to_plot};
    else,
        if act_mov_struct.plotCollapse > 0,
            toplot = inner_calc_toplot(act_mov_struct.plotCollapse, iDim, volume_to_plot);
        else,
            toplot = act_mov_struct.D4(volume_to_plot, v{1}, v{2}, v{3});
            dims = [];
            for iDim_tmp = 1:3,
                if length(v{iDim_tmp}) > 1,
                    dims = [dims; length(v{iDim_tmp})];
                end;
            end;
            toplot = reshape(toplot, dims(1), dims(2));
            toplot = toplot';
            toplot = toplot(end:(-1):1, :);
        end;
    end;
    if act_mov_struct.plotCollapse > 0,
        if isinf(act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.minVal),
            act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.minVal = min([act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.minVal; min(toplot(:))]);
            act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.maxVal = max([act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.maxVal; max(toplot(:))]);
        end;
        caxisA = act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.minVal;
        caxisB = act_mov_struct.views{act_mov_struct.plotCollapse, iDim}.maxVal;
    else,
        caxisA = min(act_mov_struct.D4(:));
        caxisB = max(act_mov_struct.D4(:));
    end;
    if diff([caxisA caxisB]) <= 0,
        caxisA = 0;
        caxisB = 1;
    end;
    iSP = iDim;
    subplot(act_mov_struct.axis_id(iAxes));
    cla;
    iAxes = iAxes + 1;
    h = imagesc(toplot);
    axis off;
    axis tight;
    caxis([caxisA, caxisB]);
end;
for iSummary = 1:2,
    subplot(act_mov_struct.axis_id(iAxes));
    cla;
    iAxes = iAxes + 1;
    f = find(act_mov_struct.x_loaded_at_last_summary == 0);
    if isempty(f) && ~isempty(act_mov_struct.timecourses{iSummary}.curve),
        mac = act_mov_struct.timecourses{iSummary}.curve;
    else,
        if iSummary == 1,
            mac = max(act_mov_struct.D4, [], 4);
            mac = max(mac, [], 3);
            mac = max(mac, [], 2);
        else,
            Diff = abs(diff(act_mov_struct.D4));
            mac = max(Diff, [], 4);
            mac = max(mac, [], 3);
            mac = max(mac, [], 2);
            mac = [mac(1); mac(:)];
        end;
        act_mov_struct.timecourses{iSummary}.curve = mac;
        if iSummary == 2,
            x = act_mov_struct.x_loaded;
            x(2:end) = x(2:end) .* x(1:(end - 1));
            act_mov_struct.x_loaded_at_last_summary = x;
        end;
    end;
    if iSummary == 1,
        tmp = act_mov_struct.x_loaded;
    else,
        tmp = act_mov_struct.x_loaded_at_last_summary;
    end;
    fL = find(tmp == 1);
    if isempty(fL),
        continue;
    end;
    h = plot(fL, mac(fL), 'b-');
    nullpt = mean(mac(fL));
    hold on;
    tmp = act_mov_struct.x_loaded_at_last_summary;
    if iSummary == 2,
        tmp(2:end) = tmp(2:end) + tmp(1:(end - 1));
    end;
    f = find(tmp == 0);
    if ~isempty(f),
        h = plot(f, nullpt, 'r+');
    end;
    ylim0 = [min(mac(fL)) - 1, max(mac(fL)) + 1];
    if diff(ylim0) < 0 || length(find(isnan(ylim0))) > 0,
        ylim0([-1 1]);
    end;
    h = plot([volume_to_plot, volume_to_plot], ylim0, 'k-');
    xlim([0, size(act_mov_struct.D4, 1) + 1]);
    ylim(ylim0);
    if iSummary == 1,
        set(gca, 'XTick', []);
        ylabel('Max');
    else
        ylabel('Abs-D');
    end;
    if iSummary == 1,
        title(num2str(volume_to_plot));
    end;
    if iSummary == 2,
        xlabel(['Mode: space = ' num2str(act_mov_struct.mode_space) ': ' act_mov_struct.viewLabels{act_mov_struct.mode_space + 1} ', time = ' num2str(act_mov_struct.mode_time)]);
    end;
end;

drawnow;

act_mov_struct.sweep0 = act_mov_struct.sweep0 + act_mov_struct.d_sweep0;
if act_mov_struct.sweep0 > act_mov_struct.sweep0_end || act_mov_struct.sweep0 < act_mov_struct.sweep0_start,
    if act_mov_struct.d_sweep0 > 0,
        act_mov_struct.sweep0 = act_mov_struct.sweep0_start;
    else,
        act_mov_struct.sweep0 = act_mov_struct.sweep0_end;
    end;
    if act_mov_struct.plotSelectedTime == 0,
        act_mov_struct.ix = 1 + mod(act_mov_struct.ix, size(act_mov_struct.D4, 1));
    end;
end;

if act_mov_struct.closeWindowReq == 1,
    stop(act_mov_struct.t);
    inner_final_close_window;
end;

function calculate_matrices
global act_mov_struct;

view_to_calc = 0;
dim_to_calc = 0;
volume_to_calc = 0;
empty_found = 0;
for o = 1:length(act_mov_struct.x),
    if act_mov_struct.x_loaded(o) == 0,
        continue;
    end;
    for n = 1:(size(act_mov_struct.views, 1) - 1),
        if empty_found == 1,
            break;
        end;
        for m = 1:size(act_mov_struct.views, 2),
            if empty_found == 1,
                break;
            end;
            if isempty(act_mov_struct.views{n, m}.toplot{o}),
                view_to_calc = n;
                dim_to_calc = m;
                volume_to_calc = o;
                empty_found = 1;
                break;
            end;
        end;
    end;
end;

if empty_found == 0,
    stop(act_mov_struct.tC);
    return;
end;

toplot = inner_calc_toplot(view_to_calc, dim_to_calc, volume_to_calc);

act_mov_struct.views{view_to_calc, dim_to_calc}.toplot{volume_to_calc} = toplot;
act_mov_struct.views{view_to_calc, dim_to_calc}.minVal = min([act_mov_struct.views{view_to_calc, dim_to_calc}.minVal; min(toplot(:))]);
act_mov_struct.views{view_to_calc, dim_to_calc}.maxVal = max([act_mov_struct.views{view_to_calc, dim_to_calc}.maxVal; max(toplot(:))]);

function toplot = inner_calc_toplot(plotCollapse, iDim, volume_to_plot)
global act_mov_struct;
if plotCollapse == 1,
    toplot = act_mov_struct.D4(volume_to_plot, :, :, :);
    fnan = find(isnan(toplot));
    toplot(fnan) = 0;
    toplot = max(toplot, [], iDim + 1);
elseif plotCollapse == 2,
    toplot = act_mov_struct.D4(volume_to_plot, :, :, :);
    fnan = find(isnan(toplot));
    toplot(fnan) = 0;
    toplot = var(toplot, 0, iDim + 1);
elseif plotCollapse == 3,
    vA{1} = 1:size(act_mov_struct.D4, 2);
    vA{2} = 1:size(act_mov_struct.D4, 3);
    vA{3} = 1:size(act_mov_struct.D4, 4);
    vB = vA;
    d = max(1, ceil(act_mov_struct.downDim(iDim) / act_mov_struct.origDim(iDim)));
    vB{iDim} = vB{iDim} - d;
    f = find(vB{iDim} < 1);
    vA{iDim}(f) = [];
    vB{iDim}(f) = [];
    toplotA = act_mov_struct.D4(volume_to_plot, vA{1}, vA{2}, vA{3});
    toplotB = act_mov_struct.D4(volume_to_plot, vB{1}, vB{2}, vB{3});
    toplot = toplotA - toplotB;
    f = find(toplotA == 0 | toplotB == 0);
    toplot(f) = 0;
    f = find(toplotA > 0 & toplotB > 0);
    toplot(f) = 1 ./ exp(abs(toplotA(f) - toplotB(f)));
    f = find(isinf(toplot));
    if ~isempty(f),
        ninf = fin(~isinf(toplot(:)));
        toplot(f) = max(toplot(ninf));
    end;
    if max(toplot(:)) ~= 0,
        toplot = toplot * max(act_mov_struct.D4(:)) / max(toplot(:));
    end;
    toplot = max(toplot, [], iDim + 1);
end;
v{1} = 1:size(act_mov_struct.D4, 2);
v{2} = 1:size(act_mov_struct.D4, 3);
v{3} = 1:size(act_mov_struct.D4, 4);
dims = [];
for iDim_tmp = 1:3,
    if iDim_tmp ~= iDim,
        dims = [dims; length(v{iDim_tmp})];
    end;
end;
toplot = reshape(toplot, dims(1), dims(2));
toplot = toplot';
toplot = toplot(end:(-1):1, :);
