function hiro3_up_down(step)

global hiro3_mem;

% base on highest layer
iLayer = hiro3_last_layer;

if iLayer < 1,
    return;
end;

% z-step
zStep = hiro3_mem.layers{iLayer}.headerinfo.mat(3, 3);
index0 = sub2ind(size(hiro3_mem.layers{iLayer}.data), hiro3_mem.layers{iLayer}.coords(1), hiro3_mem.layers{iLayer}.coords(2), hiro3_mem.layers{iLayer}.coords(3));
xyz = hiro3_mem.layers{iLayer}.xyz(:, index0);
xyz(3) = xyz(3) + step * zStep;
hiro3_set_coords(xyz);
