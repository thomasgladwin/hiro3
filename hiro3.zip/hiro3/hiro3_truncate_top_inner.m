function hiro3_truncate_top_inner(perc)

global hiro3_mem;

f = find(hiro3_mem.layers{1}.data > perc / 100);
min0 = min(hiro3_mem.layers{1}.data(f));
max0 = max(hiro3_mem.layers{1}.data(f));
hiro3_mem.layers{1}.data(f) = min0;
