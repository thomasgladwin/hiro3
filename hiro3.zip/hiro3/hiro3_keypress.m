function hiro3_keypress(dum1, dum2)

global hiro3_mem;

c = get(gcf, 'CurrentCharacter');

if strcmp(c, 'c'),
    hiro3_cutoff;
end;

if strcmp(c, 'j'),
    hiro3_jump;
end;

if strcmp(c, 'b'),
    hiro3_blobbify;
end;

if strcmp(c, 't'),
    hiro3_redraw_transversals(3);
    return;
end;
if strcmp(c, 's'),
    hiro3_redraw_transversals(1);
    return;
end;

if strcmp(c, '-'),
    hiro3_undo_change;
end;

if strcmp(c, ' '),
    hiro3_mem.onClick = mod(hiro3_mem.onClick + 1, 2);
    if hiro3_mem.onClick == 0,
        hiro3_popup_message('Click mode changed to navigate');
    end;
    if hiro3_mem.onClick == 1,
        hiro3_popup_message('Click mode changed to replace');
    end;
end;

if strcmp(c, 'r'),
    hiro3_set_replace_value;
end;

if strcmp(c, 'i'),
    hiro3_info;
end;

if strcmp(c, 'g'),
    hiro3_redraw_glass;
    return;
end;

hiro3_redraw;
