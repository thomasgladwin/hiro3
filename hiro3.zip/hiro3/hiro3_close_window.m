function hiro3_close_window(dum1, dum2)

global hiro3_mem;

% Truly delete invisible windows
try,
    delete(hiro3_mem.fid_color_scheme_GUI);
    delete(hiro3_mem.fid_timecourse_GUI);
catch,
end;

try,
    clear global hiro3_mem;
catch,
end;

delete(gcf);
