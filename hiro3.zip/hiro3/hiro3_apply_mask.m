function hiro3_apply_mask(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 3,
    return;
end;
if isempty(hiro3_mem.layers{2}.data) || isempty(hiro3_mem.layers{3}.data),
    return;
end;
if sum(abs(size(hiro3_mem.layers{2}) - size(hiro3_mem.layers{3}))) > 0,
    fprintf('Masks can only applied when layers 2 and 3 have equal dimensions.\n');
    return;
end;

% f = find(abs(hiro3_mem.layers{2}.data) < hiro3_mem.layers{2}.cutoff);
% hiro3_mem.layers{3}.data(f) = 0;
f = find(abs(hiro3_mem.layers{length(hiro3_mem.layers)}.data) == 0);
for iLayer = 2:(length(hiro3_mem.layers) - 1),
    hiro3_mem.layers{iLayer}.data(f) = 0;
end;

hiro3_redraw;
