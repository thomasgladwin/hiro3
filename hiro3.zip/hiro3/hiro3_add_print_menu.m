function hiro3_add_print_menu

set(gcf, 'Menubar', 'none');
% MENU
menu_file = uimenu('Label','Figure.');
uimenu(menu_file,'Label','Print to tiff...','Callback',@hiro3_save_picture);
