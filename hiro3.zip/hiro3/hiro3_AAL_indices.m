function hiro3_AAL_indices(varargin)

global hiro3_mem;

for n = 1:length(hiro3_mem.template.labels),
    fprintf([num2str(n) '\t' hiro3_mem.template.labels{n}]);
    if mod(n, 2) == 1,
        fprintf('\t\t\t');
    else
        fprintf('\n');
    end;
end;
