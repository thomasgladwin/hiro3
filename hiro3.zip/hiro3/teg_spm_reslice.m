function [D, H] = teg_spm_reslice(H0, BB, vox)

% function [D, H] = teg_spm_reslice(H0, BB, vox)
%
% BB and vox in mm; columns are y (AP), x (ML), z dimensions.
%
% Helper-function for spm_sample_vol.
%
% Example: 
%
%  H0 = spm_vol('volume_i.nii');
%  [D, H] = teg_spm_reslice(H0, [-128 -72 -42; 116 72 42], [4 4 4])
%  spm_write_vol(H, D);
%
% Thomas Gladwin, 2016

y = BB(1, 1):vox(1):BB(2, 1);
x = BB(1, 2):vox(2):BB(2, 2);
z = BB(1, 3):vox(3):BB(2, 3);
newdims = [length(x), length(y), length(z)];
xPlane = x(:) * ones(1, length(y));
yPlane = ones(length(x), 1) * (y(:)');
H = H0;
H.dim = newdims;
% H.dt = [16, 0];
D = zeros(newdims);
for iz = 1:length(z),
    zPlane = z(iz) * ones(size(xPlane));
    resliced_plane = spm_sample_vol(H0, yPlane, xPlane, zPlane, 1);
    D(:, :, iz) = resliced_plane;
end;
