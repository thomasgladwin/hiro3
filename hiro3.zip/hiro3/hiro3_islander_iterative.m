function [L, info] = hiro3_islander_iterative(y_b, t_cut)

% Ici est ne pas plus de une!
%
% Thomas E. Gladwin, Mariet van Buuren, Matthijs Vink. 2007.
% For information or bug reports, please email thomasgladwin@hotmail.com

% Inits
L = zeros(size(y_b));
info.COM = [];
info.peak_indices = [];
info.peak_value = [];
info.N = [];
info.label = [];
info.table = [];
[Dx, Dy, Dz] = size(L);
%
% Get label map
for posneg = [-1 1],
    [L0, peak_indices0, peak0, waterlevel, opticrit] = internal(posneg * y_b, t_cut);
    if length(unique(L0(:))) > 12,
        %L0 = ignorance(posneg * y_b, L0, peak_indices0, waterlevel, opticrit);
    end;
    L = L + posneg * L0;
end;
%
% Get info
u = unique(L);
for iG = 1:length(u),
    if u(iG) == 0,
        continue;
    end;
    f = find(L == u(iG));
    wix = 0;
    wiy = 0;
    wiz = 0;
    S = sum(y_b(f));
    for iVoxel = 1:length(f),
        [ix, iy, iz] = ind2sub([Dx, Dy, Dz], f(iVoxel));
        w = y_b(f(iVoxel));
        wix = wix + ix * w;
        wiy = wiy + iy * w;
        wiz = wiz + iz * w;
    end;
    wix = wix / S;
    wiy = wiy / S;
    wiz = wiz / S;
    info.COM = [info.COM; [wix wiy wiz]];
    info.N = [info.N length(f)];
    info.label = [info.label u(iG)];
    info.table = [info.table; u(iG) length(f) [wix wiy wiz]];
    [maxval, maxvali] = max(y_b(f));
    [minval, minvali] = min(y_b(f));
    if abs(maxval) > abs(minval),
        pv = maxval;
        pvi = f(maxvali);
    else,
        pv = minval;
        pvi = f(minvali);
    end;
    info.peak_value = [info.peak_value pv(1)];
    info.peak_indices = [info.peak_indices pvi(1)];
end;



function [L, seeds, peak_values, waterlevels, opticrit] = internal(y_b, t_cut)
global V0;
L = zeros(size(y_b));
peak = [];
V = zeros(size(y_b));
f = find(y_b > t_cut);
V(f) = y_b(f);
[Dx, Dy, Dz] = size(V);
%
levels = sort(V(f));
levels = unique(levels);
seeds = [];
opticrit = [];
waterlevels = [];
for waterlevel = levels(end:(-1):1)',
    waterlevels = [waterlevels waterlevel];
    contention = [];
    %fprintf('Waterlevel at %g...\n', waterlevel);
    L0 = zeros(size(L));
    % Assign voxels on beaches.
    islands_found = find(L);
    V0 = (V >= waterlevel);
    V0(islands_found) = 0;
    f = find(V0);
    for index = f,
        neighbours = getNeighbours(L, index);
        neighbours_vals = getNeighbours(y_b, index);
        u = unique(neighbours);
        u(find(u == 0)) = [];
        if ~isempty(u),
            [vals, counts] = tc(u);
            L0(index) = vals(end);
            V0(index) = false;
        end;
    end;
    % Find new islands
    while ~isempty(find(V0)),
        f0 = find(V0);
        [sortedvals, ind] = sort(V(f0));
        seed0 = f0(ind(end));
        seeds = [seeds seed0];
        [ix, iy, iz] = ind2sub([Dx, Dy, Dz], seed0);
        if length(f0) < 100,
            visited = spreader(ix, iy, iz, [], 1);
        else,
            visited = f0;
        end;
        V0(visited) = false;
        L0(visited) = length(seeds);
    end;
    already_assigned = find(L ~= 0);
    L0(already_assigned) = 0;
    L = L + L0;
    opticrit = [opticrit [sum(y_b(find(L))) / length(seeds)]];
end;
peak_values = y_b(seeds);





function visited = spreader(ix, iy, iz, visited, recursion_step)
global V0;
[Dx, Dy, Dz] = size(V0);
membership = [];
thisind = sub2ind([Dx, Dy, Dz], ix, iy, iz);
% Ending conditions
if ~isempty(find(visited == thisind)),
    return;
end;
if recursion_step > 100,
    %fprintf('Recursion safety level exceeded: spreading truncated.\n');
    return;
end;
if ix < 1 | ix > Dx | iy < 1 | iy > Dy | iz < 1 | iz > Dz,
    return;
end;
if V0(ix, iy, iz) == 0,
    return;
end;
% Recursion
visited = [visited thisind];
for ixn = max(1, ix - 1):min(ix + 1, Dx),
    for iyn = max(1, iy - 1):min(iy + 1, Dy),
        for izn = max(1, iz - 1):min(iz + 1, Dz),
            if ixn == ix & iyn == iy & izn == iz,
                continue;
            end;
            visited = spreader(ixn, iyn, izn, visited, recursion_step + 1);
        end;
    end
end





function neighbours = getNeighbours(V, ind)
[Dx, Dy, Dz] = size(V);
[ix, iy, iz] = ind2sub([Dx, Dy, Dz], ind);
neighbours = [];
for ixn = max(1, ix - 1):min(ix + 1, Dx),
    for iyn = max(1, iy - 1):min(iy + 1, Dy),
        for izn = max(1, iz - 1):min(iz + 1, Dz),
            if ixn == ix & iyn == iy & izn == iz,
                continue;
            end;
            neighbours = [neighbours V(ixn, iyn, izn)];
        end;
    end
end





function [vals, counts] = tc(varargin)
% function [val, count] = tc(vec)
% function [val, count] = tc(vec, plotit)
%
% t-count: my hist function
vec = varargin{1};
vals = unique(vec);
counts = [];
for val = vals,
    n = length(find(vec == val));
    counts = [counts n];
end;
[counts, indices] = sort(counts);
vals = vals(indices);





function L0 = ignorance(V, L0, peak_indices0, waterlevel, opticrit);
% % Peak finder
% figure; plot(opticrit);
% maxval = 0;
% f = 0;
% for f2 = 2:(length(opticrit) - 1),
%     if opticrit(f2) > opticrit(f2 - 1) & opticrit(f2) > opticrit(f2 + 1),
%         if opticrit(f2) > maxval,
%             maxval = opticrit(f2);
%             f = f2;
%         end;
%     end;
% end;
u = unique(L0);
meansPerBlob = [];
for n = 1:length(u),
    meansPerBlob = [meansPerBlob mean(V(find(L0 == u(n))))];
end;
crit = [];
for n = 1:(length(u) - 1),
    crit0 = sum(meansPerBlob((n + 1):end)) - sum(meansPerBlob((n + 1):end)) / n;
    crit = [crit crit0];
end;
%[zerodum, f] = find(crit > 0);
[maxdum, f] = max(crit);
L0(find(L0 > f(1))) = 0;
%figure; plot(crit)
