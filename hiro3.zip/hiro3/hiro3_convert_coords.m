function co = hiro3_convert_coords(target, twinid, vin, fileType)

global hiro3_mem winid;

rangeTemplate = zeros(3, 2);
rangeTemplate(1, :) = [min(hiro3_mem{twinid}.Y{target}(:)) max(hiro3_mem{twinid}.Y{target}(:))];
rangeTemplate(2, :) = [min(hiro3_mem{twinid}.X{target}(:)) max(hiro3_mem{twinid}.X{target}(:))];
rangeTemplate(3, :) = [min(hiro3_mem{twinid}.Z{target}(:)) max(hiro3_mem{twinid}.Z{target}(:))];
xyz0 = hiro3_voxel2xyz(vin, fileType);
rel_co(1) = (xyz0(1) - rangeTemplate(1, 1)) ./ (rangeTemplate(1, 2) - rangeTemplate(1, 1));
rel_co(2) = (xyz0(2) - rangeTemplate(2, 1)) ./ (rangeTemplate(2, 2) - rangeTemplate(2, 1));
rel_co(3) = (xyz0(3) - rangeTemplate(3, 1)) ./ (rangeTemplate(3, 2) - rangeTemplate(3, 1));
co = floor(rel_co .* size(hiro3_mem{twinid}.data{target}) + 0.5);
