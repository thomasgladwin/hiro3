function hiro3_mouseDown(dum1, dum2)

global hiro3_mem;

hiro3_getPoint;
if hiro3_mem.onClick == 1, % change value
    x = 0;
    for iLayer = 2:length(hiro3_mem.layers),
        if ~isempty(hiro3_mem.layers{iLayer}.data),
            x = iLayer;
        end;
    end;
    if x > 0,
        iLayer = x;
        c = hiro3_mem.layers{iLayer}.coords;
        iChange = length(hiro3_mem.changes) + 1;
        hiro3_mem.changes{iChange}.coords = c;
        hiro3_mem.changes{iChange}.value = hiro3_mem.layers{iLayer}.data(c(1), c(2), c(3));
        hiro3_mem.layers{iLayer}.data(c(1), c(2), c(3)) = hiro3_mem.replace_value;
    end;
end;
hiro3_redraw;
