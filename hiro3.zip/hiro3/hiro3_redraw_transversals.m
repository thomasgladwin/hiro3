function hiro3_redraw_transversals(varargin)

global hiro3_mem;

if isempty(hiro3_mem.layers{2}.data),
    return;
end;
[x, y, z] = size(hiro3_mem.layers{2}.data);
slice_select = hiro3_mem.layers{2}.xyz(3, 1:(x * y):end);

iView = varargin{end};
hiro3_plot_transversals_inner(slice_select, iView);

