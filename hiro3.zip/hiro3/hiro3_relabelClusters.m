function hiro3_relabelClusters(varargin)

global hiro3_mem;

response = inputdlg('Start numbering at...', 'Starting label number', 1, {'1'});
if isempty(response),
    return;
end;

label0 = str2num(response{1});
if isempty(label0),
    return;
end;

hiro3_relabelClusters_inner(label0);

