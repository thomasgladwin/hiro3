function template_label = hiro3_get_template_label(varargin)

global hiro3_mem winid;

vin = varargin{1};
fileType = varargin{2};

if isempty(hiro3_mem{winid}.data{fileType}),
    template_label = '';
    return;
end;
co = hiro3_convert_coords(3, winid, vin, fileType);
try,
    template_val = hiro3_mem{winid}.data{3}(co(1), co(2), co(3));
    template_label = hiro3_mem{winid}.template_labels{1}{template_val};
catch,
    template_label = 'No_label';
end;
