function hiro3_send_to_workspace(varargin)

global hiro3_mem

assignin('base', 'h3data', hiro3_mem);
fprintf('Hiro3 information saved to h3data.\n');
