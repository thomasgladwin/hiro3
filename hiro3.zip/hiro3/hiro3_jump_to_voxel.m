function hiro3_jump_to_voxel(varargin)

global hiro3_mem;

% base on highest layer
lastLayer = hiro3_last_layer;

if lastLayer < 1,
    return;
end;

response = inputdlg('Jump to xyz [mm] position', 'Position', 1, hiro3_mem.last_voxel_jump);
if ~isempty(response),
    hiro3_mem.last_voxel_jump = response;
    spaces0 = findstr(response{1}, ' ');
    d1 = str2num(response{1}(1:(spaces0(1) - 1)));
    d2 = str2num(response{1}((spaces0(1) + 1):(spaces0(2) - 1)));
    d3 = str2num(response{1}((spaces0(2) + 1):end));
    if ~isempty(d1) && ~isempty(d2) && ~isempty(d3),
        xyz = [d1 d2 d3];
        hiro3_set_coords(xyz);
    end;
end;

hiro3_redraw;
