function hiro3_relabelClusters_inner(label0)

global hiro3_mem;

for iLayer = 2:length(hiro3_mem.layers),
    fAll = [];
    u = unique(hiro3_mem.layers{iLayer}.data);
    u(u == 0) = [];
    for iu = 1:length(u),
        f = find(hiro3_mem.layers{iLayer}.data == u(iu));
        hiro3_mem.layers{iLayer}.data(f) = label0 - 1 + iu;
    end;
    label0 = label0 + length(u);
end;

hiro3_redraw;
