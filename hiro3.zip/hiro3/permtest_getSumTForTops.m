function R = permtest_getSumTForTops(filenames, nIts, sizeOrT, bn_save, LandC)

% sizeOrT:
%   0 = size
%   1 = sum-t
%   2 = median t
%   3 = min t

R.nIts = nIts;
R.filenames = filenames;
R.sizeOrT = sizeOrT;
R.LandC = LandC;

R.D = {};
for ix = 1:length(R.filenames),
    fn = [R.filenames{ix}];
    H = spm_vol(fn);
    R.D{ix} = spm_read_vols(H);
end;

[R.nBlobsReal, R.maxBlobPowerReal, R.tcrit, R.info, R.sumTReal, R.L, R.H, R.sumT, R.Torig] = inner_perm(R, 0);
fprintf(['\tReal data: nBlobs = ' num2str(R.nBlobsReal) ', max score = ' num2str(max(R.maxBlobPowerReal)) '.\n']);

if R.LandC == 0,
    [R.nBlobs, R.maxBlobPowers, R.maxBlobPower95] = inner(R);
    R.f_sig_blobs = find(R.sumTReal > R.maxBlobPower95);
    fprintf(['\tMax T sum 95 = ' num2str(R.maxBlobPower95) '\n']);
else,
    R.f_sig_blobs = 1:length(R.sumTReal);
end;

R.nBlobsSig = length(R.f_sig_blobs);
fprintf(['\n\tReal data: nBlobs = ' num2str(R.nBlobsReal) ', max score = ' num2str(max(R.maxBlobPowerReal)) ', nBlobs sig = ' num2str(R.nBlobsSig) '.\n']);

% Save label map / mask and T
savelab = {'Lsig_', 'T_', 'L_'};
for iDataToSave = 1:3,
    fn = R.filenames{1};
    H = spm_vol(fn);
    H.fname = [savelab{iDataToSave} bn_save '.nii'];
    if iDataToSave == 1,
        keeplabels = R.info.label(R.f_sig_blobs);
        tmp = 0 * R.L;
        for il = 1:length(keeplabels),
            f = find(R.L == keeplabels(il));
            tmp(f) = keeplabels(il);
        end;
        R.Lsig = tmp;
        clear tmp;
        H.dt = [4 0];
        D = R.Lsig;
    elseif iDataToSave == 2,
        H.dt = [16 0];
        D = R.Torig;
    elseif iDataToSave == 3,
        H.dt = [4 0];
        D = R.L;
    end;
    spm_write_vol(H, D);
end;

function [nBlobs, maxBlobPowers, maxBlobPower95] = inner(R)
nBlobs = [];
maxBlobPowers = [];
dispstr = '';
for iIt = 1:R.nIts,
    [nBlobs0, maxBlobPower0, R.tcrit, info, sumtv, L, H, sumT] = inner_perm(R, 1);
    nBlobs = [nBlobs; nBlobs0];
    maxBlobPowers = [maxBlobPowers; maxBlobPower0];
    dispstr = ['Iteration ' num2str(iIt) ': nBlobs = ' num2str(nBlobs0) ', max T sum = ' num2str(mean(maxBlobPower0)) '\n'];
    fprintf(dispstr);
end;
sorted = sort(maxBlobPowers, 'ascend');
a = ceil(0.95 * length(sorted));
maxBlobPower95 = sorted(a);

function [nBlobs, maxBlobPower0, tcrit, info, sumtv, L, H, sumT, T] = inner_perm(R, permit0)
fn = [R.filenames{1}];
H = spm_vol(fn);
[D] = spm_read_vols(H);
S2 = zeros(size(D));
S = zeros(size(D));

for ix = 1:length(R.filenames),
    D = R.D{ix};
    if permit0 == 1,
        D = (-1 + 2 * rand) .* D;
    end;
    S = S + D;
    S2 = S2 + D .^ 2;
end;

N = length(R.filenames);
M = S ./ N;
V = (S2 - (S .^ 2) / N) / (N - 1);

clear S
clear S2

SE = sqrt(V) ./ sqrt(N - 1);
T = M ./ SE;

clear M
clear V
clear SE

T(T == 0) = NaN;
T = abs(T);
T = 1 - tcdf(T, N - 1); % Replace T by p-based values
if R.LandC == 1,
    fOverPCrit = find(T > 0.005);
    T(fOverPCrit) = NaN;
end;
% fOverPCrit = find(T > 0.05 / length(find(~isnan(T))));
T(T == 0) = eps;
T(T > 0.05) = NaN;
fnz = find(T > 0);
T(fnz) = log(T(fnz))./log(0.05);
% T = T .^ 2;
% tcrit = tinv(1 - 0.05, N - 1);
tcrit = 0;
% T(T <= tcrit) = 0;
T(isnan(T)) = 0;

if R.LandC == 0,
    [L, info] = islander_recursive2016(T);
else
    [L, info] = islander_recursive2016(T, 1);
    u = unique(L);
    u(u == 0) = [];
    info.label = [];
    for iu = 1:length(u),
        f = find(L == u(iu));
        if length(f) < 20,
            L(f) = NaN;
        else,
            info.label = [info.label; u(iu)];
        end;
    end;
end;

nBlobs = info.N;

u = info.label;
sumtv = [];
sumT = zeros(size(T));
if length(u) > 0,
    for iu = 1:length(u),
        f = find(L == u(iu));
        if R.sizeOrT == 0,
            sumt0 = length(f);
            sumtv = [sumtv; sumt0];
        elseif R.sizeOrT == 1,
            sumt0 = sum(T(f));
            sumtv = [sumtv; sumt0];
        elseif R.sizeOrT == 2,
            sumt0 = median(T(f));
            sumtv = [sumtv; sumt0];
        elseif R.sizeOrT == 3,
            sumt0 = min(T(f) .^ 2) * length(f);
            sumtv = [sumtv; sumt0];
        end;
        sumT(f) = sumt0;
    end;
    saveval = max(sumtv);
    if isnan(saveval),
        saveval = 0;
    end;
    maxBlobPower0 = saveval;
else
    maxBlobPower0 = 0;
end;
