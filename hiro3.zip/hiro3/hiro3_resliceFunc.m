function hiro3_resliceFunc()

global mem

if isempty(mem.anatomy) || isempty(mem.func),
    return;
end;
mem.func = interp3(mem.funcX, mem.funcY, mem.funcZ, mem.func, mem.anatX, mem.anatY, mem.anatZ);
