function hiro3

% Hiro3, version 2.0.
%
% FMRI plotting program, interface. analysis.
%
% Thomas Gladwin (2015). Thanks to Matthijs Vink, Bram Zandbelt and Mariet van Buuren for feedback on an earlier version.
%
% Please cite using Gladwin TE, Vink M, Mars RB (2016). A landscape-based cluster analysis using recursive search instead of a threshold parameter. MethodsX, 3: 477-482, doi: 10.1016/j.mex.2016.06.002.
%
% Use at own risk. Newest updates at tegladwin.com/Code

% First steps.
global hiro3_mem;
hiro3_mem.fid = figure;
hiro3_create_color_scheme_GUI; % assigns .fid_color_scheme_GUI
hiro3_create_timecourse_GUI; % assigns .fid_timecourse_GUI
figure(hiro3_mem.fid);
p = get(gcf, 'Position');
p([3 4]) = [560 319];
set(gcf, 'Position', p);

% Set up memory structure
hiro3_mem.lastfilename = ''; % for starting directory on load
hiro3_mem.layers = {}; % each layer has a filename, headerinfo, etc. See hiro3_init_layer.
hiro3_init_layer(1, 'anatomy'); % Prepare layer 1: anatomy
hiro3_mem.ax0 = {}; % Prepare plotting
hiro3_mem.ax0 = [0 0 0 0 0]; % 3 views, infobox, control elements
hiro3_colormap; % Set combination-colormap
hiro3_mem.active_dimension = []; % Interfacing
hiro3_mem.row = 0;
hiro3_mem.column = 0;
hiro3_mem.cutoff = 0;
hiro3_mem.onClick = 0; % 0 = navigate, 1 = change value
hiro3_mem.changes = {}; % .coords, .value
hiro3_mem.replace_value = 0;
hiro3_mem.crosshairs = 1;
hiro3_mem.user_loaded = 0;
hiro3_mem.wd = pwd;
hiro3_mem.previous_filenames = {};

% Aal map and labels
[p] = fileparts(which('hiro3'));
filename = [p '/raal_MNI_V4.img'];
hiro3_mem.template.headerinfo = spm_vol(filename);
[hiro3_mem.template.data, hiro3_mem.template.xyz] = spm_read_vols(hiro3_mem.template.headerinfo);
hiro3_mem.template.data = flipdim(hiro3_mem.template.data, 1);
file = fopen([p '/aal_MNI_V4.txt']);
n = 1;
while ~feof(file),
    hiro3_mem.template.labels{n} = fgetl(file);
    n = n + 1;
end;
fclose(file);
filename = [p '/TD_brodmann.img'];
hiro3_mem.templateBrodmann.headerinfo = spm_vol(filename);
[hiro3_mem.templateBrodmann.data, hiro3_mem.templateBrodmann.xyz] = spm_read_vols(hiro3_mem.templateBrodmann.headerinfo);

% Set up intro pic, and remember axes for deletion.
[p] = fileparts(which('hiro3'));
intropic_file = [p '/intro.jpg'];
try,
    intropic = imread(intropic_file);
    image(intropic); axis off; axis equal;
catch,
    fprintf('intro.jpg not found.');
end;
hiro3_mem.intro_axes = gca;

set(gcf, 'Color', [0 0 0]);
set(gcf, 'Name', 'Hiro3');
set(gcf, 'WindowButtonDownFcn', @hiro3_mouseDown);
set(gcf, 'WindowButtonUpFcn', @hiro3_mouseUp);
set(gcf, 'WindowButtonMotionFcn', @hiro3_mouseMove);
set(gcf, 'CloseRequestFcn', @hiro3_close_window);
set(gcf, 'KeyPressFcn', @hiro3_keypress);
set(gcf, 'Menubar', 'none');
% MENU
menu_file = uimenu('Label','Files...');
uimenu(menu_file,'Label','Load anatomy','Callback',{@hiro3_load_file, 'anatomy'});
uimenu(menu_file,'Label','Remove anatomy','Callback',{@hiro3_remove_data, 'anatomy'});
uimenu(menu_file,'Label','Add activation layer','Callback',{@hiro3_load_file, 'functional'}, 'Separator','on');
uimenu(menu_file,'Label','Remove activation layer','Callback',{@hiro3_remove_data, 'functional'});
uimenu(menu_file,'Label','Save activation layer','Callback',{@hiro3_save_file}, 'Separator','on');
menu_file = uimenu('Label','Display...');
uimenu(menu_file,'Label','Save snapshot','Callback',@hiro3_save_picture);
uimenu(menu_file,'Label','Color schemes','Callback',{@hiro3_show_color_scheme_GUI, 'on'});
uimenu(menu_file,'Label','Toggle crosshairs','Callback',{@hiro3_toggle_crosshairs});
uimenu(menu_file,'Label','Contrast enhance', 'Callback',@hiro3_contrast_enhance);
uimenu(menu_file,'Label','Jump to value...','Callback',{@hiro3_jump}, 'Separator','on');
uimenu(menu_file,'Label','Jump to AAL index...','Callback',{@hiro3_jump_AAL});
uimenu(menu_file,'Label','Print out AAL indices...','Callback',{@hiro3_AAL_indices});
uimenu(menu_file,'Label','Plot glass brain','Callback',{@hiro3_redraw_glass, 3}, 'Separator', 'on');
uimenu(menu_file,'Label','Plot transversals (auto)','Callback',{@hiro3_redraw_transversals, 3}, 'Separator', 'on');
%uimenu(menu_file,'Label','Plot transversals (select)','Callback',{@hiro3_redraw_transversals, 3});
uimenu(menu_file,'Label','Plot selection, any slice direction','Callback',{@hiro3_redraw_transversals_select_slices});
uimenu(menu_file,'Label','Legend for discrete values','Callback',{@hiro3_draw_legend});
%uimenu(menu_file,'Label','Time course','Callback',{@hiro3_show_time_course_GUI, 'on'});
uimenu(menu_file,'Label','Activation movie','Callback',{@hiro3_activation_movie, 'on'});
menu_file = uimenu('Label','Data...');
uimenu(menu_file,'Label','Retain only voxels with values...','Callback',@hiro3_removeExcept);
uimenu(menu_file,'Label','Replace value-set with value...','Callback',@hiro3_replaceWith);
uimenu(menu_file,'Label','Set replace value in Replace-mode...','Callback',@hiro3_set_replace_value);
uimenu(menu_file,'Label','Set cut-off','Callback',{@hiro3_cutoff}, 'Separator','on');
uimenu(menu_file,'Label','Transform to mask','Callback',{@hiro3_make_mask}, 'Separator','on');
uimenu(menu_file,'Label','Transform to outline','Callback',{@hiro3_make_outline, hiro3_mem.cutoff});
uimenu(menu_file,'Label','Transform to outline (zero cutoff)','Callback',{@hiro3_make_outline, 0});
uimenu(menu_file,'Label','Apply top layer as mask','Callback',{@hiro3_apply_mask}, 'Separator','on');
uimenu(menu_file,'Label','Mask using values...','Callback',@hiro3_removeExcept);
uimenu(menu_file,'Label','Merge activation layers','Callback',{@hiro3_merge_layers}, 'Separator','on');
uimenu(menu_file,'Label','Merge label maps','Callback',{@hiro3_merge_labels});
uimenu(menu_file,'Label','Send to workspace','Callback',@hiro3_send_to_workspace, 'Separator','on');
uimenu(menu_file,'Label','Display information','Callback',@hiro3_info);
uimenu(menu_file,'Label','Discretize','Callback',{@hiro3_discretize}, 'Separator','on');
uimenu(menu_file,'Label','Remove negative values','Callback',{@hiro3_remove_negative}, 'Separator','on');
uimenu(menu_file,'Label','Reverse positive - negative','Callback',{@hiro3_reverse});
menu_file = uimenu('Label','Cluster analysis...');
% uimenu(menu_file,'Label','Run blobbify','Callback',@hiro3_blobbify);
% uimenu(menu_file,'Label','Run blobbify recursive','Callback',@hiro3_blobbify_recursive);
uimenu(menu_file,'Label','Create landscape-based clusters','Callback',@hiro3_blobbify_recursive);
uimenu(menu_file,'Label','Remove small clusters...','Callback',{@hiro3_remove_small_clusters});
uimenu(menu_file,'Label','Export blob-information and map with combined and size-selected blobs...','Callback',@hiro3_blobbify_borg);
uimenu(menu_file,'Label','Re-label clusters...','Callback',@hiro3_relabelClusters);
uimenu(menu_file,'Label','Cluster-based permutation test','Callback',@hiro3_permtest, 'Separator','on');
uimenu(menu_file,'Label','Two-group cluster-based permutation test','Callback',@hiro3_permtest_2group);
uimenu(menu_file,'Label','Re-run previous two-group cluster-based permutation test','Callback',@hiro3_permtest_2group_rerun);
uimenu(menu_file,'Label','Two-group cluster size at p=check-it permutation test','Callback',@hiro3_permtest_2group_clustersize);
uimenu(menu_file,'Label','Re-run previous two-group cluster size permutation test','Callback',@hiro3_permtest_2group_clustersize_rerun);
uimenu(menu_file,'Label','Two-group cluster excession at p=check-it permutation test','Callback',@hiro3_permtest_2group_excession);
uimenu(menu_file,'Label','Re-run previous two-group cluster excession at p=check-it permutation test','Callback',@hiro3_permtest_2group_excession_rerun);
%uimenu(menu_file,'Label','Run replicability functions','Callback',@hiro3_replicability);
menu_file = uimenu('Label','Help');
uimenu(menu_file,'Label','Help and info','Callback',@hiro3_help);

hiro3_help;

% Standard anaomy
hiro3_load_file_internal([p '/T1.nii'], [], 'anatomy');
