function hiro3_redraw_transversals_select_slices(varargin)

global hiro3_mem;

if isfield(hiro3_mem, 'def_slice_choice'),
    deffy = hiro3_mem.def_slice_choice;
else,
    deffy = '';
end;
if length(varargin) < 3,
    answer2=inputdlg('Slice dimension (1, 2, 3)','Select view',1,{'2'});
    try,
        iView = str2num(answer2{1});
        if isempty(iView == [1 2 3]),
            return;
        end;
    catch,
        return;
    end;
else,
    iView = 3;
end;
answer=inputdlg('Z-coordinate [mm]','Select slices',1,{deffy});
try,
    slice_select = str2num(answer{1});
catch,
    return;
end;
if isempty(slice_select),
    return;
end;
hiro3_mem.def_slice_choice = answer{1};

hiro3_plot_transversals_inner(slice_select, iView);

