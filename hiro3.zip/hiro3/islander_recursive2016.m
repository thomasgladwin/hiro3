function [L, info] = islander_recursive2016(varargin)

% Declare L and T as global to avoid it being compied endlessly during recrusion
global T;
global L;
global LocMax;
global current_L_val;
T = varargin{1};
L = zeros(size(T));
borgify_param = 0;

if length(varargin) < 2,
    LandC = 0;
else,
    LandC = varargin{2};
end;

% Get LocMax
inner_get_LocMax();

current_L_val = 1;
while 1,
    ind0_hlm = inner_find_highest_local_max();
    if isempty(ind0_hlm),
        break;
    end;
    
    L(ind0_hlm) = current_L_val;
    inner_add_peak(ind0_hlm, LandC);

    f = find(L == current_L_val);
%     fprintf(['Peak size = ' num2str(length(f)) '\n']);
    LocMax(f) = 0;

    current_L_val = current_L_val + 1;
end;

L = borgify(L, T, borgify_param);

info = inner_get_info();

function inner_get_LocMax()
global T;
global LocMax;
LocMax = zeros(size(T));
T_tmp = T;
for ix = 2:(size(T, 1) - 1),
    for iy = 2:(size(T, 2) - 1),
        for iz = 2:(size(T, 3) - 1),
            box0 = T_tmp((ix - 1):(ix + 1), (iy - 1):(iy + 1), (iz - 1):(iz + 1));
            box0(2, 2, 2) = -Inf;
            if max(box0(:)) <= T_tmp(ix, iy, iz) && T_tmp(ix, iy, iz) > 0,
                LocMax(ix, iy, iz) = 1;
                T_tmp((ix - 1):(ix + 1), (iy - 1):(iy + 1), (iz - 1):(iz + 1)) = 0;
            end;
        end;
    end;
end;

function ind_hlm = inner_find_highest_local_max()
global T;
global LocMax;
fLocMax = find(LocMax(:) > 0);
% fprintf(['N of local maxima = ' num2str(length(fLocMax)) '\n']);
[maxval, ind0] = max(T(fLocMax));
ind_hlm = fLocMax(ind0);

function inner_add_peak(ind0_hlm, LandC)
global L;
global T;
global recdepth;
global Visited;
global current_L_val;
global to_colonize;
to_colonize = [];
Visited = zeros(size(T));
recdepth = 0;
current_ind = ind0_hlm;
slope_history = [];
value_history = [];

[ix, iy, iz] = ind2sub(size(T), current_ind);
inner_cascade_recursive(ix, iy, iz, value_history, slope_history, ix, iy, iz, LandC);

% % Colonize neighbours: In borgify
% u = unique(to_colonize);
% L = colonize(L, T, current_L_val, u);

function inner_cascade_recursive(ix, iy, iz, value_history, slope_history, ix0, iy0, iz0, LandC)
global L;
global T;
global current_L_val;
global recdepth;
global Visited;
global to_colonize;

% Visited(ix, iy, iz) = 1;

% fprintf([num2str(current_L_val) '. ']);
% fprintf(['\tDepth: ' num2str(recdepth) '\n']);

recdepth = recdepth + 1;
this_val = T(ix, iy, iz);
if ~isempty(value_history),
    this_slope = this_val - value_history(end);
else
    this_slope = NaN;
end;
% fprintf(['\tVal = ' num2str(this_val), ' slope = ' num2str(this_slope) '\n']);

% Stopping criterion
stop_here = 0;
if LandC == 0,
    if length(value_history) > 1,
    %     rising0 = this_val > min(value_history);
    %     rising0 = this_slope > 0 || this_slope > slope_history(end);
        rising0 = this_slope > slope_history(end);
    %     rising0 = 0;
    else,
        rising0 = 0;
    end;
    if rising0 || this_val <= 0 || isnan(this_val),
        stop_here = 1;
    end;
else,
    if isnan(this_val) || this_val == 0,
        stop_here = 1;
    end;
end;

if stop_here == 1,
%     fprintf(['\tStopped at ' num2str([ix iy iz]) '\n']);
    recdepth = recdepth - 1;
    return;
end;

% Add this voxel
% fprintf(['\tAdding and continuing from voxel, at ' num2str([ix iy iz]) '\n']);
L(ix, iy, iz) = current_L_val;
value_history = [value_history; this_val];
if ~isnan(this_slope),
    slope_history = [slope_history; this_slope];
end;

% Spread
for dx = [-1, 0, 1],
    for dy = [-1, 0, 1],
        for dz = [-1, 0, 1],
            ix2 = ix + dx;
            iy2 = iy + dy;
            iz2 = iz + dz;
            if min([ix2; iy2; iz2]) < 1,
                continue;
            end;
            if ix2 > size(T, 1) || iy2 > size(T, 2) || iz2 > size(T, 3),
                continue;
            end;
            if Visited(ix2, iy2, iz2) == 1,
                continue;
            end;
            if L(ix2, iy2, iz2) ~= 0,
                % Colonize adjacent blob
                l0 = L(ix2, iy2, iz2);
                to_colonize = [to_colonize; l0];
                continue;
            end;
            if (T(ix2, iy2, iz2) <= 0),
                continue;
            end;
            dOld = sqrt((ix - ix0) ^ 2 + (iy - iy0) ^ 2 + (iz - iz0) ^ 2);
            dNew = sqrt((ix2 - ix0) ^ 2 + (iy2 - iy0) ^ 2 + (iz2 - iz0) ^ 2);
            if dNew < dOld,
%                 fprintf('\tPreventing double-back\n');
                continue;
            end;
            %             fprintf(['\tSearching ' num2str([dx dy dz]) '\n']);
            inner_cascade_recursive(ix2, iy2, iz2, value_history, slope_history, ix0, iy0, iz0, LandC);
        end;
    end;
end;

function info = inner_get_info
global T;
global L;
u = unique(L(L ~= 0));
info.label = u;
info.N = length(u);
info.mean_ind = [];
for iu = 1:length(u),
    f = find(L == u(iu));
    [x, y, z] = ind2sub(size(L), f);
    mx = mean(x);
    my = mean(y);
    mz = mean(z);
    info.mean_ind = [info.mean_ind; mx my mz];
end;
