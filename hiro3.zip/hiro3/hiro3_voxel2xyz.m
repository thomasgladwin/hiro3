function [xyz] = voxel2xyz(vin, fileType)

% function [xyz] = voxel2xyz(vin, fileType)
%
% vin = [voxel_index_1, 2, 3]
%
% Thomas E. Gladwin, Mariet van Buuren, Matthijs Vink. 2007.
% For information or bug reports, please email thomasgladwin@hotmail.com

global hiro3_mem winid;

xyz(2) = hiro3_mem{winid}.X{fileType}(1) + (vin(2) / size(hiro3_mem{winid}.data{fileType}, 2)) * (hiro3_mem{winid}.X{fileType}(end) - hiro3_mem{winid}.X{fileType}(1));
xyz(1) = hiro3_mem{winid}.Y{fileType}(1) + (vin(1) / size(hiro3_mem{winid}.data{fileType}, 1)) * (hiro3_mem{winid}.Y{fileType}(end) - hiro3_mem{winid}.Y{fileType}(1));
xyz(3) = hiro3_mem{winid}.Z{fileType}(1) + (vin(3) / size(hiro3_mem{winid}.data{fileType}, 3)) * (hiro3_mem{winid}.Z{fileType}(end) - hiro3_mem{winid}.Z{fileType}(1));
