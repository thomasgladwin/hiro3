function hiro3_lighten_anatomy(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 1,
    return;
end;

ld = varargin{end};

hiro3_lighten_anatomy_inner(ld);
hiro3_redraw;
