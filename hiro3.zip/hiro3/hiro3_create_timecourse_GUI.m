function hiro3_create_timecourse_GUI

% Create color scheme GUI

global hiro3_mem;

hiro3_mem.fid_timecourse_GUI = figure;
set(hiro3_mem.fid_timecourse_GUI, 'Visible', 'off');
