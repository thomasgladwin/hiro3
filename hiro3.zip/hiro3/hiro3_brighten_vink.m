function hiro3_brighten_vink(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 1,
    return;
end;

m = mean(hiro3_mem.layers{1}.data(:));
sd = var(hiro3_mem.layers{1}.data(:)) .^ 0.5;
crit = m + 3 * sd;
f = find(hiro3_mem.layers{1}.data > crit);
hiro3_mem.layers{1}.data(f) = crit;
hiro3_redraw;
