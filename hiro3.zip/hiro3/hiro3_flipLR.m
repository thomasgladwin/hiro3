function hiro3_flipLR(varargin)

global hiro3_mem winid;

fileType = str2num(varargin{3});
if ~isempty(hiro3_mem{winid}.data{fileType}),
    hiro3_mem{winid}.data{fileType} = flipdim(hiro3_mem{winid}.data{fileType}, 1);
end;
hiro3_fillPlotMatrix();
hiro3_redraw;
