function hiro3_set_coords(xyz)

global hiro3_mem;

for iLayer = 1:length(hiro3_mem.layers),
    if isfield(hiro3_mem.layers{iLayer}, 'data'),
        if isempty(hiro3_mem.layers{iLayer}.data),
            continue;
        end;
    else,
        continue;
    end;
    d = (hiro3_mem.layers{iLayer}.xyz - xyz(:) * ones(1, size(hiro3_mem.layers{iLayer}.xyz, 2))) .^ 2;
    d = sum(d);
    [sorted, indices] = sort(d);
    [d1 d2 d3] = ind2sub(size(hiro3_mem.layers{iLayer}.data), indices(1));
    hiro3_mem.layers{iLayer}.coords = [d1 d2 d3];
end;

hiro3_redraw;
