function hiro3_mouseMove(dum1, dum2)

% Work in progress
