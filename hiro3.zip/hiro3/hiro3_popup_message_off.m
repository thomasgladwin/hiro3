function hiro3_popup_message_off(axid)

delete(axid);

set(gcf, 'Visible', 'on');
pause(0.001);
refresh;
