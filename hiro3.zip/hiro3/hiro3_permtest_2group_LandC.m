function hiro3_permtest_2group(varargin)

global hiro3_mem;

wd = hiro3_mem.wd;
filename_spmsel = spm_select(Inf, 'image', 'Select file', [], wd);
if size(filename_spmsel, 1) == 0,
    return;
end;
try,
    hiro3_mem.wd = fileparts(filename_spmsel(1, :));
catch,
    hiro3_mem.wd = pwd;
end;
filenames = {};
for n = 1:size(filename_spmsel, 1),
    filenames{1}{n} = strtrim(filename_spmsel(n, :));
end;
[p0, bn] = fileparts(filenames{1}{1});

filename_spmsel = spm_select(Inf, 'image', 'Select file', [], wd);
if size(filename_spmsel, 1) == 0,
    return;
end;
try,
    hiro3_mem.wd = fileparts(filename_spmsel(1, :));
catch,
    hiro3_mem.wd = pwd;
end;
for n = 1:size(filename_spmsel, 1),
    filenames{2}{n} = strtrim(filename_spmsel(n, :));
end;

hiro3_mem.previous_filenames = filenames;

disp('Running...');
hiro3_mem.R_permtest = permtest_getSumTForTops_2groups(filenames, 10000, 1, ['hiro3_permtest_' bn '.nii'], 1);
disp('Complete. Export h3mem to workspace to get information.');
