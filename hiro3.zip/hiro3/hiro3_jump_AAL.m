function hiro3_jump_AAL(varargin)

global hiro3_mem;

response = inputdlg('Jump to AAL label', 'Label value', 1);
if ~isempty(response),
    response = str2num(response{1});
    if ~isempty(response),
        iLayer = hiro3_last_layer;
        f = find(hiro3_mem.template.data == response);
        if ~isempty(f),
            xyz = hiro3_mem.template.xyz(:, f(1));
            hiro3_set_coords(xyz);
        end;
    end;
end;

hiro3_redraw;
