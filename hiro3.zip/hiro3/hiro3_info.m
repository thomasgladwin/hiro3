function hiro3_info(varargin)

global hiro3_mem;

for iLayer = 1:length(hiro3_mem.layers),
    if ~isfield(hiro3_mem.layers{iLayer}, 'data'),
        continue;
    end;
    if isempty(hiro3_mem.layers{iLayer}.data),
        continue;
    end;
    fprintf(['* * * Layer ' num2str(iLayer) ' * * *\n']);
    disp(hiro3_mem.layers{iLayer});
    disp(hiro3_mem.layers{iLayer}.headerinfo);
    disp(hiro3_mem.layers{iLayer}.headerinfo.mat);
end;
