function hiro3_show_timecourse_GUI(varargin)

global hiro3_mem;

onoff = varargin{end};

figure(hiro3_mem.fid_timecourse_GUI);
clf;
if strcmp(onoff, 'on'),
    set(hiro3_mem.fid_timecourse_GUI, 'Visible', 'on');
else,
    set(hiro3_mem.fid_timecourse_GUI, 'Visible', 'off');
end;
set(gcf, 'Name', 'Time course');
set(gcf, 'Menubar', 'none');
set(gcf, 'CloseRequestFcn', 'set(gcf, ''Visible'', ''off'');');
