function hiro3_set_transparency(dum1, dum2, iLayer, u, transparencystr);

global hiro3_mem;

value = get(u, 'Value');
hiro3_mem.layers{iLayer}.transparency = str2num(transparencystr{value}) / 100;
hiro3_redraw;
