function hiro3_load_file_internal(varargin)

global hiro3_mem;

fileTypeStr = varargin{3};
reslice = 0;
if length(varargin) > 3,
    reslice = varargin{4};
end;
iLayer = 0;
if strcmp(fileTypeStr, 'anatomy'),
    iLayer = 1;
elseif strcmp(fileTypeStr, 'functional'),
    % Find last non-empty functional layer
    x = 0;
    for iLayer = 2:length(hiro3_mem.layers),
        if ~isempty(hiro3_mem.layers{iLayer}.data),
            x = iLayer;
        end;
    end;
    if x == 0,
        iLayer = 2;
    else,
        iLayer = x + 1;
    end;
end;
if iLayer == 0,
    fprintf('Unknown file type in load_file\n');
    return;
end;

if isempty(hiro3_mem.lastfilename),
    wd = pwd;
else,
    try,
        wd = fileparts(hiro3_mem.lastfilename);
    catch,
        wd = pwd;
    end;
end;
% filename = spm_select(1, 'image', 'Select file', [], wd);
filename = varargin{1};

if isempty(filename),
    return;
end;

hiro3_load_file_inner(filename, iLayer, fileTypeStr, reslice);
