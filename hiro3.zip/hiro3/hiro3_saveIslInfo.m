function info = saveIslInfo(filename, info)

% Thomas E. Gladwin, Mariet van Buuren, Matthijs Vink. 2007.
% For information or bug reports, please email thomasgladwin@hotmail.com

global hiro3_mem;

% Labels and real-world coords
info.xyz = zeros(length(info.label), 3);
for iLabel = 1:length(info.label),
    index0 = sub2ind(size(hiro3_mem.layers{2}.data), ceil(info.COM(iLabel, 1)), ceil(info.COM(iLabel, 2)), ceil(info.COM(iLabel, 3)));
    info.xyz(iLabel, 1:3) = hiro3_mem.layers{2}.xyz(:, index0)';
    info.id{iLabel} = hiro3_get_label(info.xyz(iLabel, 1:3));
    info.brodmann{iLabel} = hiro3_get_BA(info.xyz(iLabel, 1:3));
end;

if isempty(filename),
    assignin('base', 'blobinfo', info);
    return;
end;

file = fopen(filename, 'w');
fprintf(file, 'Label\tVox1\tVox2\tVox3\tN\tPeakValue\tX\tY\tZ\tBA\tID\n');
for iLabel = 1:length(info.label),
    fprintf(file, [num2str(info.label(iLabel)) '\t']);
    fprintf(file, [num2str(info.COM(iLabel, 1), 4) '\t']);
    fprintf(file, [num2str(info.COM(iLabel, 2), 4) '\t']);
    fprintf(file, [num2str(info.COM(iLabel, 3), 4) '\t']);
    fprintf(file, [num2str(info.N(iLabel)) '\t']);
    fprintf(file, [num2str(info.peak_value(iLabel)) '\t']);
    fprintf(file, [num2str(info.xyz(iLabel, 1)) '\t']);
    fprintf(file, [num2str(info.xyz(iLabel, 2)) '\t']);
    fprintf(file, [num2str(info.xyz(iLabel, 3)) '\t']);
    fprintf(file, [info.brodmann{iLabel} '\t']);
    fprintf(file, [info.id{iLabel} '\t']);
    fprintf(file, '\n');
end;
fclose(file);
