function hiro3_activation_movie(varargin)

global hiro3_mem;

wd = hiro3_mem.wd;
filename = spm_select(Inf, 'image', 'Select file', [], wd);
try,
    hiro3_mem.wd = fileparts(filename(1, :));
catch,
    hiro3_mem.wd = pwd;
end;
activation_movie(filename);
