function hiro3_cutoff(varargin)

global hiro3_mem;

response = inputdlg('Enter cutoff', 'Cutoff', 1);
if ~isempty(response),
    response = str2num(response{1});
    if ~isempty(response),
        if length(response) == 1,
            hiro3_mem.cutoff = response;
            for iLayer = 2:length(hiro3_mem.layers),
                hiro3_mem.layers{iLayer}.cutoff = response;
            end;
        else,
            hiro3_mem.cutoff = response(1);
            for iLayer = 2:length(hiro3_mem.layers),
                hiro3_mem.layers{iLayer}.cutoff = response(iLayer - 1);
            end;
        end;
    end;
end;

hiro3_redraw;
