function hiro3_set_replace_value(varargin)

global hiro3_mem;

answer = inputdlg('Replace value');
if isempty(answer),
    return;
end;

v = str2num(answer{1});
if isempty(v),
    return;
end;
hiro3_mem.replace_value = v;
