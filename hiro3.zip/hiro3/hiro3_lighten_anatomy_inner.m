function hiro3_lighten_anatomy_inner(ld)

global hiro3_mem;

if ld == 1,
    hiro3_mem.layers{1}.data = hiro3_mem.layers{1}.data .^ (3/4);
else,
    hiro3_mem.layers{1}.data = hiro3_mem.layers{1}.data .^ (4/3);
end;
