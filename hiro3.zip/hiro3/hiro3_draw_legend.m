function hiro3_draw_legend(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 2,
    return;
end;

u = unique(hiro3_mem.layers{2}.data);
u(find(u == 0)) = [];

numlines = 1;
defaultanswer = {};
prompt = {};
for n = 1:length(u),
    prompt{n} = ['Label ' num2str(n)];
    defaultanswer{n} = ['Label ' num2str(u(n))];
end;
if isfield(hiro3_mem, 'discrete_legend'),
    if length(prompt) == length(hiro3_mem.discrete_legend),
        defaultanswer = hiro3_mem.discrete_legend;
    end;
end;
answer = inputdlg(prompt,'Legend labels',numlines,defaultanswer);
hiro3_mem.discrete_legend = answer;

figure; clf; colormap(hiro3_mem.colormap);
hiro3_add_print_menu

set(gcf, 'Color', [0 0 0]);
% nR = ceil(sqrt(length(u)) * 2);
% nC = ceil(length(u) / nR);
% if length(u) == 8,
%     nR = 2; nC = 4;
% end;
nR = length(u);
nC = 1;
cid = 8;
allmax = max(u);
for n = 1:length(u),
    if u(n) == 0,
        continue;
    end;
    subplot(nR, nC, n);
    cv = floor(hiro3_mem.colors.starts(cid) + (hiro3_mem.colors.ends(cid) - hiro3_mem.colors.starts(cid)) * (u(n) - 1) / allmax);
    toplot_temp = ones(2, 2) * cv;
    im0 = image([0 1], [0 1], toplot_temp, 'CDataMapping', 'direct');
    t0 = text(1.95, 0.25, hiro3_mem.discrete_legend{n});
    set(t0, 'Color', [1 1 1]);
    xlim([0 5]);
    ylim([0 1]);
    axis off equal tight;
end;
