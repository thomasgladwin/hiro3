function hiro3_reverse(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 2,
    return;
end;

iL = hiro3_last_layer;
hiro3_mem.layers{iL}.data = -hiro3_mem.layers{iL}.data;
hiro3_redraw;
