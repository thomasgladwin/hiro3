function hiro3_reorient(iLayer)

global hiro3_mem

fprintf(['Not flipping dimensions: Left and right could be reversed on-screen.\n']);
return;

% Reverse if any direction is negative
low_xyz_index = sub2ind(size(hiro3_mem.layers{iLayer}.data), 1, 1, 1);
low_xyz = hiro3_mem.layers{iLayer}.xyz(:, low_xyz_index);
high_xyz_index = sub2ind(size(hiro3_mem.layers{iLayer}.data), size(hiro3_mem.layers{iLayer}.data, 1), size(hiro3_mem.layers{iLayer}.data, 2), size(hiro3_mem.layers{iLayer}.data, 3));
high_xyz = hiro3_mem.layers{iLayer}.xyz(:, high_xyz_index);
for n = 1:3,
    if high_xyz(n) < low_xyz(n),
        xvec = hiro3_mem.layers{iLayer}.xyz(n, :);
        xvec = reshape(xvec, size(hiro3_mem.layers{iLayer}.data));
        xvec = flipdim(xvec, n);
        hiro3_mem.layers{iLayer}.xyz(n, :) = xvec(:)';
        hiro3_mem.layers{iLayer}.data = flipdim(hiro3_mem.layers{iLayer}.data, n);
        hiro3_mem.layers{iLayer}.headerinfo.mat(n, n) = -hiro3_mem.layers{iLayer}.headerinfo.mat(n, n);
        hiro3_mem.layers{iLayer}.headerinfo.mat(n, 4) = high_xyz(n); % high voxel is low mm
        fprintf(['Flipping dimension ' num2str(n) '.\n']);
    end;
end;
