function hiro3_undo_change

global hiro3_mem;

if length(hiro3_mem.changes) == 0,
    return;
end;

x = 0;
for iLayer = 2:length(hiro3_mem.layers),
    if ~isempty(hiro3_mem.layers{iLayer}.data),
        x = iLayer;
    end;
end;
if x == 0,
    return;
end;
iLayer = x;

c = hiro3_mem.changes{end}.coords;
v = hiro3_mem.changes{end}.value;
hiro3_mem.layers{iLayer}.data(c(1), c(2), c(3)) = v;

temp = hiro3_mem.changes;
hiro3_mem.changes = {};
for n = 1:(length(temp) - 1),
    hiro3_mem.changes{n} = temp{n};
end;
