function hiro3_discretize(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 2,
    return;
end;

u = unique(hiro3_mem.layers{2}.data(:));
temp = zeros(size(hiro3_mem.layers{2}.data));
val = 1;
for n = 1:length(u),
    if u(n) == 0,
        continue;
    end;
    f = find(hiro3_mem.layers{2}.data(:) == u(n));
    temp(f) = val;
    val = val + 1;
end;
hiro3_mem.layers{2}.data = temp;
hiro3_mem.layers{2}.color_id = 8;
hiro3_mem.layers{2}.cutoff = 0;
hiro3_mem.cutoff = 0;
hiro3_redraw;
