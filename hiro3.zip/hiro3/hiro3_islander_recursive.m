function [L, info] = hiro3_islander_recursive(y_b, threshold0)

% Ici est ne pas plus de une!

% Inits
L = zeros(size(y_b));
info.COM = [];
info.peak_indices = [];
info.peak_value = [];
info.N = [];
info.label = [];
info.table = [];
[Dx, Dy, Dz] = size(L);
%

y_b(abs(y_b) < threshold0) = NaN;
[L, info0] = islander_recursive2016(y_b);

%
% Get info
u = unique(L);
for iG = 1:length(u),
    if u(iG) == 0,
        continue;
    end;
    f = find(L == u(iG));
    wix = 0;
    wiy = 0;
    wiz = 0;
    S = sum(y_b(f));
    for iVoxel = 1:length(f),
        [ix, iy, iz] = ind2sub([Dx, Dy, Dz], f(iVoxel));
        w = y_b(f(iVoxel));
        wix = wix + ix * w;
        wiy = wiy + iy * w;
        wiz = wiz + iz * w;
    end;
    wix = wix / S;
    wiy = wiy / S;
    wiz = wiz / S;
    info.COM = [info.COM; [wix wiy wiz]];
    info.N = [info.N length(f)];
    info.label = [info.label u(iG)];
    info.table = [info.table; u(iG) length(f) [wix wiy wiz]];
    [maxval, maxvali] = max(y_b(f));
    [minval, minvali] = min(y_b(f));
    if abs(maxval) > abs(minval),
        pv = maxval;
        pvi = f(maxvali);
    else,
        pv = minval;
        pvi = f(minvali);
    end;
    info.peak_value = [info.peak_value pv(1)];
    info.peak_indices = [info.peak_indices pvi(1)];
end;
