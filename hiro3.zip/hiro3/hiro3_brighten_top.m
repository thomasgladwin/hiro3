function hiro3_brighten_top(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 1,
    return;
end;

answer=inputdlg('Percentage to brighten','Brighten top percentage',1);
try,
    perc = str2num(answer{1});
catch,
    return;
end;
if isempty(perc),
    return;
end;

f = find(hiro3_mem.layers{1}.data > perc / 100);
min0 = min(hiro3_mem.layers{1}.data(f));
max0 = max(hiro3_mem.layers{1}.data(f));
hiro3_mem.layers{1}.data(f) = min0 + 0.5 * (max0 - min0) + 0.5 * (hiro3_mem.layers{1}.data(f) - min0) / (max0 - min0);
hiro3_redraw;
