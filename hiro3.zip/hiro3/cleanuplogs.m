function D = cleanuplogs(filename)

%Label	Vox1	Vox2	Vox3	N	PeakValue	X	Y	Z	ID
[D.label, D.v1, D.v2, D.v3, D.N, D.peakValue, D.x, D.y, D.z, D.ID] = TEXTREAD(filename, '%n%n%n%n%n%n%n%n%n%s', 'headerlines', 1);

D.namememory = {};
D.unique = {};
D.unique_peak = {};
D.unique_N = {};
for n = 1:length(D.ID),
    recognized = 0;
    for m = 1:length(D.namememory),
        if strcmp(D.ID{n}, D.namememory{m}) == 1,
            recognized = m;
        end;
    end;
    if recognized == 0,
        recognized = length(D.unique) + 1;
        D.unique{recognized} = [];
        D.unique_peak{recognized} = [];
        D.unique_N{recognized} = [];
        D.namememory{length(D.namememory) + 1} = D.ID{n};
    end;
    temp = [D.x(n); D.y(n); D.z(n)] * ones(1, D.N(n));
    D.unique{recognized} = [D.unique{recognized} temp];
    temp = D.peakValue(n) * ones(1, D.N(n));
    D.unique_peak{recognized} = [D.unique_peak{recognized} temp];
    temp = D.N(n);
    D.unique_N{recognized} = [D.unique_N{recognized} temp];
end;
temp = [];
for n = 1:length(D.namememory),
    temp = [temp max(D.unique_peak{n})];
end;
[sorted, order] = sort(temp);
file = fopen(['cleaned_' filename], 'w');
fprintf(file, 'Region\tX\tY\tZ\tPeak t-values\tNr of voxels\n');
for nn = 1:length(D.namememory),
    n = order(nn);
    D.unique{n} = floor(mean(D.unique{n}, 2));
    D.unique_peak{n} = max(D.unique_peak{n});
    D.unique_N{n} = sum(D.unique_N{n});
    name0 = '                             ';
    name0(1:length(D.namememory{n})) = D.namememory{n};
    locstr0 = '';
    for m = 1:3,
        locstr0 = [locstr0 num2str(D.unique{n}(m)) ' '];
    end;
    locstr1 = '                     ';
    locstr1(1:length(locstr0)) = locstr0;
    fprintf([name0 'loc = ' locstr1 'peakVal = ' num2str(D.unique_peak{n}) ',\tN = ' num2str(D.unique_N{n}) '\n']);
    fprintf(file, [name0  '\t' locstr1 '\t' num2str(D.unique_peak{n}) '\t' num2str(D.unique_N{n}) '\n']);
end;
fclose(file);
