function hiro3_remove_negative(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 2,
    return;
end;

iL = hiro3_last_layer;
f = find(hiro3_mem.layers{iL}.data < 0);
hiro3_mem.layers{iL}.data(f) = 0;
hiro3_redraw;
