function hiro3_new_window(dum1, dum2, linked)

global hiro3_mem winid;

for n = 1:length(hiro3_mem),
    if hiro3_mem{n}.fid == gcf,
        winid = n;
    end;
end;

linked = str2num(linked);
if linked == 1,
    hiro3(winid);
else
    hiro3(0);
end;
