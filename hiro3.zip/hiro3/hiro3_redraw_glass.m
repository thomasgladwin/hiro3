function hiro3_redraw_glass(varargin)

global hiro3_mem;

figure(hiro3_mem.fid);
colormap(hiro3_mem.colormap);

% Remove intro pic axes if onscreen.
if hiro3_mem.intro_axes ~= 0,
    delete(hiro3_mem.intro_axes);
    hiro3_mem.intro_axes = 0;
end;

% Remove previous plot axes.
for n = 1:length(hiro3_mem.ax0),
    try,
        if hiro3_mem.ax0(n) > 0,
            delete(hiro3_mem.ax0(n));
            hiro3_mem.ax0(n) = 0;
        end;
    catch,
        fprintf('Could not delete axes.\n');
        fprintf(lasterr);
    end;
end;

% check if anything is loaded
x = 0;
first = 0;
for iLayer = 1:length(hiro3_mem.layers),
    if ~isfield(hiro3_mem.layers{iLayer}, 'data'),
        continue;
    end;
    if prod(size(hiro3_mem.layers{iLayer}.data)) > 0,
        x = 1;
        first = iLayer;
        break
    end;
end;
if x == 0,
    hiro3_mem.ax0(1) = axes('position', [0 0 1 1]);
    set(gca, 'Color', [0.2 0.2 0.2]);
    axis off;
    return;
end;

% Params
margin = 0.01;
text_area = 0.2;
lastLayer = hiro3_last_layer;
% Plot views of layers
% Anatomy and functional values wil be scaled to fit into
% correct segments of a static colormap.
%
% Scale axes:
%   Horizontal: l2 : l1 : l1
%   Vertical: l3 : l3 : l2

% % For MNI normalization:
% for n = 1:3, L(n) = size(hiro3_mem.layers{first}.data, n); end;
% H_scale = [L(2) L(1) L(1)];
% H_scale = H_scale ./ max(H_scale);
% V_scale = [L(3) L(3) L(2)];
% V_scale = V_scale ./ max(V_scale);
H_scale = [1 1 1];
V_scale = [1 1 1];
common_lim = [min(hiro3_mem.min_BB) max(hiro3_mem.max_BB)];

left = margin;
perPlot = (1 - 0 * margin) / 3;
clim0 = [1 size(hiro3_mem.colormap, 1)];
maxabs = [];

for iLayer = 1:length(hiro3_mem.layers),
    allmin{iLayer} = min(hiro3_mem.layers{iLayer}.data(:));
    allmax{iLayer} = max(abs(hiro3_mem.layers{iLayer}.data(:)));
end;
for iView = 1:3,
    % set up axes
    mid_hor = margin + perPlot * (-0.5 + iView);
    mid_vert = text_area + (1 - text_area) / 2;
    width = H_scale(iView) * perPlot;
    left = mid_hor - width / 2;
    height = V_scale(iView) * (1 - text_area);
    bottom = mid_vert - height / 2;
    posrect = [left bottom width height];
    hiro3_mem.ax0(iView) = axes('position', posrect);
    axis off;
    hold on;
    for iLayer = 1:length(hiro3_mem.layers),
        if prod(size(hiro3_mem.layers{iLayer}.data)) == 0,
            continue;
        end;
        maxabs(iLayer) = max(abs(hiro3_mem.layers{iLayer}.data(:)));
        %        try,
        % get plane
        for n = 1:3,
            dimsel{n} = 1:size(hiro3_mem.layers{iLayer}.data, n);
        end;
        if iLayer > 1,
            runvec = 1:size(hiro3_mem.layers{iLayer}.data, iView);
        else,
            runvec = hiro3_mem.layers{iLayer}.coords(iView);
        end;
        for runThrough = runvec,
            dimsel{iView} = runThrough;
            if dimsel{iView} == 0 || dimsel{iView} > size(hiro3_mem.layers{iLayer}.data, iView),
                dimsel{iView} = ceil(size(hiro3_mem.layers{iLayer}.data, iView) / 2);
            end;
            toplot = hiro3_mem.layers{iLayer}.data(dimsel{1}, dimsel{2}, dimsel{3});
            toplot = squeeze(toplot);
            if iLayer > 1,
                toplot(find(abs(toplot) < hiro3_mem.layers{iLayer}.cutoff)) = 0;
            end;
            toplot = toplot'; % higher dimension is rows
            if max(toplot(:)) == min(toplot(:)),
                continue;
            end;
            % Get x, y scales for current layer
            BB_max0 = hiro3_mem.layers{iLayer}.max_BB;
            BB_max0(iView) = [];
            BB_min0 = hiro3_mem.layers{iLayer}.min_BB;
            BB_min0(iView) = [];
            X = linspace(BB_min0(1), BB_max0(1), size(toplot, 2)); % horizontal axis: columns
            Y = linspace(BB_min0(2), BB_max0(2), size(toplot, 1));
            % plot plane
            if iLayer == 1,
                % Grayscale anatomy
                if max(toplot(:)) > min(toplot(:)),
                    toplot = hiro3_mem.colors.starts(1) + floor((hiro3_mem.colors.ends(1) - hiro3_mem.colors.starts(1)) * (toplot - allmin{iLayer}) / (allmax{iLayer} - allmin{iLayer}));
                    im0 = image(X, Y, toplot, 'CDataMapping', 'direct');
                else,
                    continue;
                end;
            else,
                if max(toplot(:)) > min(toplot(:)),
                    % plot equal ranges around 0
                    cid = hiro3_mem.layers{iLayer}.color_id;
                    if cid >= 2 && cid <= 5,
                        % flat color
                        toplot_temp = zeros(size(toplot));
                        f = find(toplot > 0);
                        toplot_temp(f) = hiro3_mem.colors.ends(cid);
                        f = find(toplot < 0);
                        toplot_temp(f) = hiro3_mem.colors.starts(cid);
                    elseif cid == 8,
                        toplot_temp = hiro3_mem.colors.starts(cid) + (hiro3_mem.colors.ends(cid) - hiro3_mem.colors.starts(cid)) * (toplot - 1) / allmax{iLayer};
                    else,
                        % scales
                        half = floor((hiro3_mem.colors.ends(cid) - hiro3_mem.colors.starts(cid)) / 2);
                        zero = hiro3_mem.colors.starts(cid) + half;
                        %                         toplot_temp = zero + floor(half * toplot / allmax{iLayer});
                        toplot_temp = zeros(size(toplot));
                        f = find(toplot > 0);
                        toplot_temp(f) = zero + floor(half * (toplot(f) - hiro3_mem.layers{iLayer}.cutoff) / (allmax{iLayer} - hiro3_mem.layers{iLayer}.cutoff));
                        f = find(toplot < 0);
                        toplot_temp(f) = zero + floor(half * (toplot(f) + hiro3_mem.layers{iLayer}.cutoff) / (allmax{iLayer} + hiro3_mem.layers{iLayer}.cutoff));
                    end;
                    im0 = image(X, Y, toplot_temp, 'CDataMapping', 'direct');
                else,
                    continue;
                end;
            end;
            set(gca, 'YDir', 'normal');
            axis off;
            xlim(common_lim);
            ylim(common_lim);
            axis equal;
            % Colouring etc options
            if iLayer > 1,
                alphadata = zeros(size(toplot));
                f = find(abs(toplot) > 0);
                alphadata(f) = 1 - hiro3_mem.layers{iLayer}.transparency;
                alphadata(f) = alphadata(f) + 0.25 + 0.75 * runThrough / max(runvec);
                set(im0, 'AlphaData', alphadata);
            end;
            % Transparency
            set(hiro3_mem.ax0(iView), 'Color', 'none');
            % crosshairs on top layer
            if hiro3_mem.crosshairs == 1 && 1 == 0,
                if iLayer == lastLayer,
                    xyz_index = sub2ind(size(hiro3_mem.layers{iLayer}.data), hiro3_mem.layers{iLayer}.coords(1), hiro3_mem.layers{iLayer}.coords(2), hiro3_mem.layers{iLayer}.coords(3));
                    xyz = hiro3_mem.layers{iLayer}.xyz(:, xyz_index);
                    % control for reversed axes:
                    for n = 1:3,
                        if hiro3_mem.layers{iLayer}.headerinfo.mat(n, n) < 0,
                            xyz(n) = hiro3_mem.layers{iLayer}.min_BB(n) + hiro3_mem.layers{iLayer}.max_BB(n) - xyz(n);
                        end;
                    end;
                    xyz(iView) = [];
                    yl = [BB_min0(2) BB_max0(2)];
                    xl = [BB_min0(1) BB_max0(1)];
                    % horizontal line
                    y = xyz(2);
                    l = line(xl, [y y]);
                    set(l, 'Color', [1 1 1]);
                    % vertical line
                    x = xyz(1);
                    l = line([x x], yl);
                    set(l, 'Color', [1 1 1]);
                end;
            end;
        end;
        %         catch,
        %             fprintf(lasterr);
        %         end;
    end;
end;
% Info region
posrect = [margin margin 1 - 2 * margin text_area - margin];
hiro3_mem.ax0(4) = axes('position', posrect);
if hiro3_mem.onClick == 0,
    set(gca, 'Color', [0.5 0.5 0.7])
else,
    set(gca, 'Color', [0.7 0.5 0.5])
end;
set(gca, 'XTick', []);
set(gca, 'YTick', []);
if ~isempty(hiro3_mem.layers{1}.coords),
    txt0 = '';
    for n = 1:3,
        txt0 = [txt0 ' ' num2str(hiro3_mem.layers{1}.coords(n))];
    end;
    text(0.05, 0.15, ['Anatomical voxels: ' txt0]);
    ind = sub2ind(size(hiro3_mem.layers{1}.data), hiro3_mem.layers{1}.coords(1), ...
        hiro3_mem.layers{1}.coords(2), hiro3_mem.layers{1}.coords(3));
    txt0 = '';
    for n = 1:3,
        txt0 = [txt0 ' ' num2str(hiro3_mem.layers{1}.xyz(n, ind))];
    end;
    text(0.05, 0.4, ['Anatomical coordinates: ' txt0]);
    % Anatomical label
    xyz_index = sub2ind(size(hiro3_mem.layers{1}.data), hiro3_mem.layers{1}.coords(1), hiro3_mem.layers{1}.coords(2), hiro3_mem.layers{1}.coords(3));
    xyz = hiro3_mem.layers{1}.xyz(:, xyz_index);
    label = hiro3_get_label(xyz);
    label2 = hiro3_get_BA(xyz);
    t = text(0.05, 0.65, ['' [label ', BA: ' label2]]);
    set(t, 'Interpreter', 'none');
    % Cut-off
    if length(hiro3_mem.layers) > 1,
        t = text(0.55, 0.15, ['Threshold: ' num2str(hiro3_mem.cutoff)]);
    end;
else,
    txt0 = '';
    for n = 1:3,
        txt0 = [txt0 ' ' num2str(hiro3_mem.layers{2}.coords(n))];
    end;
    text(0.05, 0.15, ['Functional voxels: ' txt0]);
end;
if length(hiro3_mem.layers) > 1,
    if ~isempty(hiro3_mem.layers{2}.coords),
        x = hiro3_mem.layers{2}.data(hiro3_mem.layers{2}.coords(1), ...
            hiro3_mem.layers{2}.coords(2), hiro3_mem.layers{2}.coords(3));
        t = text(0.55, 0.65, ['Layer 1 value: ' num2str(x)]);
    end;
end;
if hiro3_last_layer > 2,
    if ~isempty(hiro3_mem.layers{3}.coords),
        x = hiro3_mem.layers{3}.data(hiro3_mem.layers{3}.coords(1), ...
            hiro3_mem.layers{3}.coords(2), hiro3_mem.layers{3}.coords(3));
        t = text(0.55, 0.4, ['Layer 2 value: ' num2str(x)]);
    end;
elseif hiro3_last_layer > 1,
    txt0 = '';
    for n = 1:3,
        txt0 = [txt0 ' ' num2str(hiro3_mem.layers{2}.coords(n))];
    end;
    text(0.75, 0.15, ['Vox: ' txt0]);
    ind = sub2ind(size(hiro3_mem.layers{2}.data), hiro3_mem.layers{2}.coords(1), ...
        hiro3_mem.layers{2}.coords(2), hiro3_mem.layers{2}.coords(3));
    txt0 = '';
    for n = 1:3,
        txt0 = [txt0 ' ' num2str(hiro3_mem.layers{2}.xyz(n, ind))];
    end;
    text(0.75, 0.4, ['Co: ' txt0]);
end;

% Colorbars for activation layers
for iLayer = 2:length(hiro3_mem.layers),
    if isempty(hiro3_mem.layers{iLayer}.data),
        continue;
    end;
    if maxabs(iLayer) == 0,
        continue;
    end;
    left = margin;
    width = 1 - 2 * margin;
    height = 0.025;
    bottom = text_area + (iLayer - 1) * 1.25 * height;
    posrect = [left bottom width height];
    hiro3_mem.ax0(4 + iLayer - 1) = axes('position', posrect);
    set(gca, 'Color', [1 1 1]);
    scale = linspace(-maxabs(iLayer), maxabs(iLayer), 64);
    %scale = [zeros(1, 5) scale zeros(1, 5)];
    scale = [1; 1] * scale;
    % plot equal ranges around 0
    cid = hiro3_mem.layers{iLayer}.color_id;
    if cid >= 2 && cid <= 5,
        % flat color
        toplot_temp = zeros(size(scale));
        f = find(scale > 0);
        toplot_temp(f) = hiro3_mem.colors.ends(cid);
        f = find(scale < 0);
        toplot_temp(f) = hiro3_mem.colors.starts(cid);
    elseif cid == 8, % discrete
        toplot_temp = hiro3_mem.colors.starts(cid):hiro3_mem.colors.ends(cid);
        scale = 1:length(toplot_temp);
    else,
        % scales
        half = floor((hiro3_mem.colors.ends(cid) - hiro3_mem.colors.starts(cid)) / 2);
        zero = hiro3_mem.colors.starts(cid) + half;
        toplot_temp = zero + floor(half * scale / max(abs(scale(:))));
    end;
    im0 = image(scale(1, :), [0; 1], toplot_temp, 'CDataMapping', 'direct');
    set(gca, 'YDir', 'normal');
    axis off;
    set(gca, 'YTick', []);
    set(gca, 'XTick', []);
    xl = xlim;
    d0 = (scale(1, end) - scale(1, 1)); m0 = d0 / 10;
    xlim(xl + [-m0 m0]);
    xl = xlim;
    if cid ~= 8,
        t = text(xl(1) + m0 / 2, 0.5, num2str(-maxabs(iLayer), 2));
        set(t, 'Color', [1 1 1]);
        set(t, 'HorizontalAlignment', 'Center');
        t = text(xl(end) - m0 / 2, 0.5, num2str(maxabs(iLayer), 2));
        set(t, 'Color', [1 1 1]);
        set(t, 'HorizontalAlignment', 'Center');
    end;
end;

% Filenames
posrect = [0 1 - text_area / 2 1 text_area / 2];
hiro3_mem.ax0(end + 1) = axes('position', posrect);
if hiro3_mem.onClick == 0,
    set(gca, 'Color', [0.5 0.5 0.7])
else,
    set(gca, 'Color', [0.7 0.5 0.5])
end;
set(gca, 'XTick', []);
set(gca, 'YTick', []);
for iLayer = 1:lastLayer,
    if ~isfield(hiro3_mem.layers{iLayer}, 'data'),
        continue;
    end;
    if isempty(hiro3_mem.layers{iLayer}.data),
        continue;
    end;
    t = text(0.01, iLayer / (lastLayer + 1), hiro3_mem.layers{iLayer}.filename);
    set(t, 'FontUnits', 'normalized');
    set(t, 'FontSize', 1 / (lastLayer + 1));
    set(t, 'Interpreter', 'none');
end;
