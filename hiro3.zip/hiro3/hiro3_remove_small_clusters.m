function hiro3_relabelClusters(varargin)

global hiro3_mem;

response = inputdlg('Minimum cluster size...', 'Minimum number of voxels', 1, {'20'});
if isempty(response),
    return;
end;

minsize0 = str2num(response{1});
if isempty(minsize0),
    return;
end;

for iLayer = 2:length(hiro3_mem.layers),
    u = unique(hiro3_mem.layers{iLayer}.data);
    u(u == 0) = [];
    for iu = 1:length(u),
        f = find(hiro3_mem.layers{iLayer}.data == u(iu));
        if length(f) < minsize0,
            hiro3_mem.layers{iLayer}.data(f) = 0;
        end;
    end;
end;

hiro3_redraw;
