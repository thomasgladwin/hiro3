function hiro3_make_mask(varargin)

global hiro3_mem;

if length(hiro3_mem.layers) < 2,
    return;
end;
if isempty(hiro3_mem.layers{2}.data),
    return;
end;
f = find(abs(hiro3_mem.layers{2}.data > hiro3_mem.cutoff));
hiro3_mem.layers{2}.data = zeros(size(hiro3_mem.layers{2}.data));
hiro3_mem.layers{2}.data(f) = 1;

hiro3_mem.layers{2}.color_id = 2;
hiro3_mem.layers{2}.cutoff = 0.5;
hiro3_redraw;
